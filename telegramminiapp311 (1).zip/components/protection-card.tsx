"use client"

import { useState } from "react"
import { ChevronRight, Zap, Eye, Bell, Loader2, ShieldOff } from "lucide-react"
import { LottieAnimation } from "./lottie-animation"
import { ANIMATIONS } from "@/lib/animations"

interface ProtectionCardProps {
  isEnabled: boolean
  onConnect: () => Promise<void>
  onDisconnect: () => Promise<void>
  stats: {
    blocked: number
    alerts: number
    scans: number
  }
  isLoading?: boolean
}

export function ProtectionCard({ isEnabled, onConnect, onDisconnect, stats, isLoading }: ProtectionCardProps) {
  const [isExpanded, setIsExpanded] = useState(false)
  const [connecting, setConnecting] = useState(false)
  const [disconnecting, setDisconnecting] = useState(false)

  const handleConnect = async () => {
    setConnecting(true)
    try {
      await onConnect()
    } finally {
      setConnecting(false)
    }
  }

  const handleDisconnect = async () => {
    setDisconnecting(true)
    try {
      await onDisconnect()
    } finally {
      setDisconnecting(false)
    }
  }

  return (
    <div className="relative">
      {/* Main card */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full p-4 bg-gradient-to-br from-black/60 to-black/40 backdrop-blur-md rounded-2xl border-2 border-white/30 text-left transition-all hover:border-white/50 hover:scale-[1.02]"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative w-14 h-14 flex-shrink-0">
              <LottieAnimation src={ANIMATIONS.eternalRose} className="w-14 h-14" loop autoplay />
            </div>

            <div>
              <h3 className="text-white font-bold text-lg">Бесплатная защита</h3>
              <p className="text-white/50 text-sm">OSINT Shield</p>
            </div>
          </div>

          <ChevronRight className={`w-5 h-5 text-white/50 transition-transform ${isExpanded ? "rotate-90" : ""}`} />
        </div>

        {/* Status indicator */}
        <div className="mt-3 flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${isEnabled ? "bg-green-400 animate-pulse" : "bg-yellow-400"}`} />
          <span className="text-white/60 text-xs">{isEnabled ? "Защита активна" : "Нажми для активации"}</span>
        </div>
      </button>

      {/* Expanded content */}
      {isExpanded && (
        <div className="mt-2 p-4 bg-black/60 backdrop-blur-md rounded-2xl border border-white/20 animate-in slide-in-from-top-2 duration-200">
          <h4 className="text-white font-semibold mb-3">Функции защиты</h4>

          <div className="space-y-3 mb-4">
            <div className="flex items-center gap-3 text-white/70">
              <Eye className="w-4 h-4 flex-shrink-0" />
              <span className="text-sm">Блокировка OSINT ботов от сканирования профиля</span>
            </div>
            <div className="flex items-center gap-3 text-white/70">
              <Bell className="w-4 h-4 flex-shrink-0" />
              <span className="text-sm">Уведомления когда кто-то пытается вас пробить</span>
            </div>
            <div className="flex items-center gap-3 text-white/70">
              <Zap className="w-4 h-4 flex-shrink-0" />
              <span className="text-sm">Защита в реальном времени от утечки данных</span>
            </div>
          </div>

          {/* Stats */}
          {isEnabled && (
            <div className="grid grid-cols-3 gap-2 mb-4">
              <div className="p-2 bg-white/5 rounded-lg text-center border border-white/10">
                <div className="text-white font-bold">{stats.blocked}</div>
                <div className="text-white/40 text-xs">Заблок.</div>
              </div>
              <div className="p-2 bg-white/5 rounded-lg text-center border border-white/10">
                <div className="text-white font-bold">{stats.alerts}</div>
                <div className="text-white/40 text-xs">Алерты</div>
              </div>
              <div className="p-2 bg-white/5 rounded-lg text-center border border-white/10">
                <div className="text-white font-bold">{stats.scans}</div>
                <div className="text-white/40 text-xs">Сканы</div>
              </div>
            </div>
          )}

          {/* Connect/Disconnect buttons */}
          <div className="space-y-2">
            {!isEnabled ? (
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  if (!connecting) handleConnect()
                }}
                disabled={connecting || isLoading}
                className={`w-full py-3 rounded-xl font-semibold transition-all flex items-center justify-center gap-2 ${
                  connecting || isLoading
                    ? "bg-white/20 text-white cursor-wait"
                    : "bg-white text-black hover:bg-white/90 hover:scale-[1.02]"
                }`}
              >
                {connecting || isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Подключение...
                  </>
                ) : (
                  "Подключить"
                )}
              </button>
            ) : (
              <>
                <div className="w-full py-3 rounded-xl font-semibold bg-green-500/20 text-green-400 text-center border border-green-500/30">
                  Защита активна
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    if (!disconnecting) handleDisconnect()
                  }}
                  disabled={disconnecting}
                  className="w-full py-2 rounded-xl text-sm transition-all flex items-center justify-center gap-2 bg-red-500/10 text-red-400 border border-red-500/20 hover:bg-red-500/20"
                >
                  {disconnecting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Отключение...
                    </>
                  ) : (
                    <>
                      <ShieldOff className="w-4 h-4" />
                      Отключить защиту
                    </>
                  )}
                </button>
              </>
            )}
          </div>

          {isEnabled && <p className="text-center text-white/40 text-xs mt-2">Бот уведомит вас об угрозах</p>}
        </div>
      )}
    </div>
  )
}
