"use client"

import { Home, Shield, BarChart3, Settings } from "lucide-react"

interface BottomNavigationProps {
  activeTab: string
  onTabChange: (tab: string) => void
}

export function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  const tabs = [
    { id: "home", icon: Home, label: "Главная" },
    { id: "protection", icon: Shield, label: "Защита" },
    { id: "stats", icon: BarChart3, label: "Статистика" },
    { id: "settings", icon: Settings, label: "Настройки" },
  ]

  return (
    <div
      className="fixed bottom-0 left-0 right-0 z-50 p-4 pb-safe pointer-events-auto"
      style={{ paddingBottom: "max(1rem, env(safe-area-inset-bottom))" }}
    >
      <div className="flex items-center justify-around p-2 bg-black/90 backdrop-blur-xl rounded-2xl border border-white/20 shadow-lg shadow-black/50">
        {tabs.map((tab) => {
          const Icon = tab.icon
          const isActive = activeTab === tab.id

          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => onTabChange(tab.id)}
              className={`flex flex-col items-center gap-1 px-4 py-3 rounded-xl transition-all min-w-[60px] touch-manipulation ${
                isActive
                  ? "bg-white/20 text-white scale-105"
                  : "text-white/50 hover:text-white/80 active:bg-white/10 active:scale-95"
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[10px] font-medium">{tab.label}</span>
            </button>
          )
        })}
      </div>
    </div>
  )
}
