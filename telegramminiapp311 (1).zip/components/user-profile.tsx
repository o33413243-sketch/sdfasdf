"use client"

import type { TelegramUser } from "@/types/telegram"
import Image from "next/image"

interface UserProfileProps {
  user: TelegramUser | null
  isOnline: boolean
}

export function UserProfile({ user, isOnline }: UserProfileProps) {
  const displayName = user?.first_name || "Гость"
  const username = user?.username ? `@${user.username}` : "@anonymous"
  const photoUrl = user?.photo_url

  return (
    <div className="flex items-center gap-4 p-4 bg-black/40 backdrop-blur-md rounded-2xl border border-white/10">
      {/* Avatar with online status */}
      <div className="relative">
        <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-white/20 bg-white/5">
          {photoUrl ? (
            <Image
              src={photoUrl || "/placeholder.svg"}
              alt={displayName}
              width={64}
              height={64}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-black/50">
              <Image src="/anonymous.png" alt="Anonymous" width={40} height={40} className="opacity-80" />
            </div>
          )}
        </div>
        {/* Online indicator */}
        <div
          className={`absolute bottom-0 right-0 w-4 h-4 rounded-full border-2 border-black ${
            isOnline ? "bg-green-400 animate-pulse" : "bg-gray-500"
          }`}
        />
      </div>

      {/* User info */}
      <div className="flex flex-col">
        <div className="flex items-center gap-2">
          <span className="text-white font-semibold text-lg">{displayName}</span>
          {user?.is_premium && (
            <span className="px-2 py-0.5 bg-white/10 rounded-full text-xs text-white/70">Premium</span>
          )}
        </div>
        <span className="text-white/50 text-sm">{username}</span>
        <div className="flex items-center gap-1 mt-1">
          <div className={`w-2 h-2 rounded-full ${isOnline ? "bg-green-400" : "bg-gray-500"}`} />
          <span className="text-white/40 text-xs">{isOnline ? "В сети" : "Не в сети"}</span>
        </div>
      </div>
    </div>
  )
}
