"use client"

import type * as React from "react"
import { createContext, useContext, useState, useEffect } from "react"

type Theme = "dark" | "light" | "custom"

interface CustomTheme {
  backgroundImage?: string
  accentColor?: string
}

interface ThemeContextType {
  theme: Theme
  setTheme: (theme: Theme) => void
  customTheme: CustomTheme
  setCustomTheme: (customTheme: CustomTheme) => void
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setThemeState] = useState<Theme>("dark")
  const [customTheme, setCustomThemeState] = useState<CustomTheme>({
    accentColor: "#ffffff",
  })
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    // Load from localStorage
    const savedTheme = localStorage.getItem("vacwertor-theme") as Theme
    const savedCustomTheme = localStorage.getItem("vacwertor-custom-theme")

    if (savedTheme) {
      setThemeState(savedTheme)
    }
    if (savedCustomTheme) {
      try {
        setCustomThemeState(JSON.parse(savedCustomTheme))
      } catch {
        // Ignore parse errors
      }
    }
  }, [])

  const setTheme = (newTheme: Theme) => {
    setThemeState(newTheme)
    localStorage.setItem("vacwertor-theme", newTheme)
  }

  const setCustomTheme = (newCustomTheme: CustomTheme) => {
    setCustomThemeState(newCustomTheme)
    localStorage.setItem("vacwertor-custom-theme", JSON.stringify(newCustomTheme))
  }

  if (!mounted) {
    return <div className="min-h-screen bg-black" />
  }

  return (
    <ThemeContext.Provider value={{ theme, setTheme, customTheme, setCustomTheme }}>{children}</ThemeContext.Provider>
  )
}

export function useTheme() {
  const context = useContext(ThemeContext)
  if (context === undefined) {
    throw new Error("useTheme must be used within a ThemeProvider")
  }
  return context
}
