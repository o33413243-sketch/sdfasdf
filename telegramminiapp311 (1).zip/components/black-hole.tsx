"use client"

import { useEffect, useRef, useState } from "react"

interface DataStream {
  id: number
  chars: string[]
}

const symbols = "!@#$%^&*<>[]{}|/\\~0123456789ABCDEF"

function generateRandomChars(length: number): string[] {
  return Array.from({ length }, () => symbols[Math.floor(Math.random() * symbols.length)])
}

export function BlackHole() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [streams, setStreams] = useState<DataStream[]>([])
  const [processedCount, setProcessedCount] = useState(0)
  const streamIdRef = useRef(0)

  // Generate data streams with animated characters
  useEffect(() => {
    const interval = setInterval(() => {
      const newStream: DataStream = {
        id: streamIdRef.current++,
        chars: generateRandomChars(18),
      }
      setStreams(prev => [...prev.slice(-4), newStream])
    }, 1200)

    return () => clearInterval(interval)
  }, [])

  // Animate existing streams - change random chars
  useEffect(() => {
    const interval = setInterval(() => {
      setStreams(prev => prev.map(stream => ({
        ...stream,
        chars: stream.chars.map((char, i) => 
          Math.random() > 0.7 ? symbols[Math.floor(Math.random() * symbols.length)] : char
        )
      })))
    }, 100)

    return () => clearInterval(interval)
  }, [])

  // Count processed
  useEffect(() => {
    const interval = setInterval(() => {
      setProcessedCount(prev => prev + 1)
    }, 2500)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let animationId: number
    let rotation = 0
    let pulsePhase = 0

    const resize = () => {
      canvas.width = 280
      canvas.height = 280
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      const centerX = canvas.width / 2
      const centerY = canvas.height / 2

      pulsePhase += 0.02

      // Outer energy field
      for (let i = 3; i >= 0; i--) {
        const radius = 100 + i * 20 + Math.sin(pulsePhase + i) * 5
        const gradient = ctx.createRadialGradient(centerX, centerY, radius - 30, centerX, centerY, radius + 10)
        gradient.addColorStop(0, "transparent")
        gradient.addColorStop(0.5, `rgba(239, 68, 68, ${0.03 * (4 - i)})`)
        gradient.addColorStop(1, "transparent")

        ctx.beginPath()
        ctx.arc(centerX, centerY, radius, 0, Math.PI * 2)
        ctx.fillStyle = gradient
        ctx.fill()
      }

      // Data streams flowing into black hole
      for (let stream = 0; stream < 6; stream++) {
        const baseAngle = (stream / 6) * Math.PI * 2 + rotation * 0.5
        ctx.save()
        ctx.translate(centerX, centerY)
        
        for (let i = 0; i < 15; i++) {
          const t = (i / 15 + rotation * 2) % 1
          const radius = 120 - t * 80
          const angle = baseAngle + t * 0.5
          const x = Math.cos(angle) * radius
          const y = Math.sin(angle) * radius * 0.4
          
          const size = 1 + (1 - t) * 2
          const opacity = t * 0.6
          
          ctx.beginPath()
          ctx.arc(x, y, size, 0, Math.PI * 2)
          ctx.fillStyle = `rgba(239, 68, 68, ${opacity})`
          ctx.fill()
        }
        ctx.restore()
      }

      // Accretion disk with glow
      ctx.save()
      ctx.translate(centerX, centerY)
      ctx.rotate(rotation)

      // Outer ring
      for (let i = 0; i < 80; i++) {
        const angle = (i / 80) * Math.PI * 2
        const baseRadius = 55 + Math.sin(angle * 4 + rotation * 3) * 8
        const x = Math.cos(angle) * baseRadius
        const y = Math.sin(angle) * baseRadius * 0.35

        ctx.beginPath()
        ctx.arc(x, y, 2.5, 0, Math.PI * 2)
        const hue = (angle * 180 / Math.PI + rotation * 50) % 360
        ctx.fillStyle = `hsla(${hue > 180 ? 0 : 0}, ${hue > 180 ? 70 : 0}%, ${50 + Math.sin(angle) * 20}%, ${0.4 + Math.sin(angle + rotation * 2) * 0.3})`
        ctx.fill()
      }

      // Middle ring
      for (let i = 0; i < 50; i++) {
        const angle = (i / 50) * Math.PI * 2 + rotation * 1.5
        const radius = 40 + Math.sin(angle * 6) * 4
        const x = Math.cos(angle) * radius
        const y = Math.sin(angle) * radius * 0.3

        ctx.beginPath()
        ctx.arc(x, y, 1.8, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(255, 255, 255, ${0.5 + Math.sin(angle) * 0.3})`
        ctx.fill()
      }

      ctx.restore()

      // Black hole center with gradient
      const holeGradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, 32)
      holeGradient.addColorStop(0, "#000000")
      holeGradient.addColorStop(0.6, "#000000")
      holeGradient.addColorStop(0.85, "#0a0a0a")
      holeGradient.addColorStop(1, "rgba(30, 30, 30, 0.9)")

      ctx.beginPath()
      ctx.arc(centerX, centerY, 28, 0, Math.PI * 2)
      ctx.fillStyle = holeGradient
      ctx.fill()

      // Event horizon glow (pulsing)
      const glowIntensity = 0.15 + Math.sin(pulsePhase * 2) * 0.05
      const horizonGradient = ctx.createRadialGradient(centerX, centerY, 26, centerX, centerY, 40)
      horizonGradient.addColorStop(0, "transparent")
      horizonGradient.addColorStop(0.4, `rgba(239, 68, 68, ${glowIntensity})`)
      horizonGradient.addColorStop(0.7, `rgba(255, 255, 255, ${glowIntensity * 0.5})`)
      horizonGradient.addColorStop(1, "transparent")

      ctx.beginPath()
      ctx.arc(centerX, centerY, 36, 0, Math.PI * 2)
      ctx.fillStyle = horizonGradient
      ctx.fill()

      // Center icon/symbol
      ctx.fillStyle = `rgba(255, 255, 255, ${0.3 + Math.sin(pulsePhase) * 0.1})`
      ctx.font = "bold 16px monospace"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText("TOR", centerX, centerY)

      rotation += 0.008
      animationId = requestAnimationFrame(animate)
    }

    resize()
    animate()

    return () => {
      cancelAnimationFrame(animationId)
    }
  }, [])

  return (
    <div className="relative w-[300px]">
      {/* Data Terminal Window */}
      <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-[260px] z-20">
        <div className="bg-black/80 backdrop-blur-md rounded-lg border border-white/10 overflow-hidden">
          {/* Terminal header */}
          <div className="flex items-center gap-2 px-3 py-1.5 bg-white/5 border-b border-white/10">
            <div className="flex gap-1.5">
              <div className="w-2 h-2 rounded-full bg-red-500/80" />
              <div className="w-2 h-2 rounded-full bg-yellow-500/80" />
              <div className="w-2 h-2 rounded-full bg-green-500/80" />
            </div>
            <span className="text-[10px] text-white/40 font-mono flex-1 text-center">ANONYMIZER v2.0</span>
            <div className="text-[10px] text-green-500/70 font-mono animate-pulse">LIVE</div>
          </div>
          
          {/* Terminal content */}
          <div className="p-2 space-y-1.5 min-h-[70px] max-h-[70px] overflow-hidden">
            {streams.length === 0 ? (
              <div className="text-white/30 text-[10px] font-mono text-center py-4">
                ...
              </div>
            ) : (
              streams.slice(-3).map((stream, idx) => (
                <div key={stream.id} className="flex items-center gap-1 text-[10px] font-mono">
                  {stream.chars.map((char, i) => {
                    const isRed = i < 8
                    const isTransitioning = i >= 6 && i <= 9
                    const opacity = isTransitioning ? 0.5 : 0.8
                    return (
                      <span
                        key={i}
                        className={`${isRed ? 'text-red-500' : 'text-white'} transition-colors duration-300`}
                        style={{ opacity, animationDelay: `${i * 50}ms` }}
                      >
                        {char}
                      </span>
                    )
                  })}
                </div>
              ))
            )}
          </div>
          
          {/* Terminal footer */}
          <div className="px-3 py-1 bg-white/5 border-t border-white/10 flex justify-between items-center">
            <span className="text-[9px] text-white/30 font-mono">STATUS: ACTIVE</span>
            <span className="text-[9px] text-green-500/70 font-mono">{processedCount} PROTECTED</span>
          </div>
        </div>
      </div>

      {/* Black Hole Canvas */}
      <div className="pt-[85px]">
        <canvas ref={canvasRef} className="w-[280px] h-[280px] mx-auto" />
      </div>

      {/* Bottom status */}
      <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-4 text-[10px] font-mono">
        <div className="flex items-center gap-1.5">
          <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
          <span className="text-white/40">TOR CONNECTED</span>
        </div>
        <div className="text-white/20">|</div>
        <div className="text-white/40">
          <span className="text-red-400">{Math.floor(Math.random() * 50 + 150)}</span> ms
        </div>
      </div>
    </div>
  )
}
