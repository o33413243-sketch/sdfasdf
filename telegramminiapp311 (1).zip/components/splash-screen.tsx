"use client"

import { useEffect, useState, useCallback, useRef } from "react"
import Image from "next/image"

interface SplashScreenProps {
  onComplete: () => void
  username?: string
}

type LoadingStep = {
  id: string
  text: string
  subText?: string
  duration: number
  status: "pending" | "loading" | "complete" | "error"
  icon: string
}

export function SplashScreen({ onComplete, username }: SplashScreenProps) {
  const [phase, setPhase] = useState<"init" | "decrypt" | "welcome" | "loading" | "complete">("init")
  const [displayText, setDisplayText] = useState("")
  const [glitchChars, setGlitchChars] = useState<string[]>([])
  const [currentStepIndex, setCurrentStepIndex] = useState(0)
  const [stepProgress, setStepProgress] = useState(0)
  const [totalProgress, setTotalProgress] = useState(0)
  const [showLogo, setShowLogo] = useState(false)
  const [logoScale, setLogoScale] = useState(0.5)
  const [logoOpacity, setLogoOpacity] = useState(0)
  const [matrixRain, setMatrixRain] = useState<string[][]>([])
  const [hexCode, setHexCode] = useState("0x00000000")
  const [ipAddress, setIpAddress] = useState("127.0.0.1")
  const [connectionNodes, setConnectionNodes] = useState(0)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  const welcomeText = "SECURE CONNECTION"
  const profileText = username ? `@${username}` : "AGENT"
  
  const [loadingSteps, setLoadingSteps] = useState<LoadingStep[]>([
    { id: "init", text: "Инициализация ядра", subText: "Проверка системы...", duration: 600, status: "pending", icon: "SYS" },
    { id: "tor", text: "Подключение к TOR", subText: "Поиск узлов...", duration: 1000, status: "pending", icon: "TOR" },
    { id: "encrypt", text: "Шифрование", subText: "AES-256-GCM", duration: 500, status: "pending", icon: "ENC" },
    { id: "profile", text: "Загрузка профиля", subText: profileText, duration: 800, status: "pending", icon: "USR" },
    { id: "shield", text: "Активация защиты", subText: "Запуск мониторинга...", duration: 600, status: "pending", icon: "DEF" },
  ])

  const randomChar = useCallback(() => {
    const chars = "01234567890ABCDEF!@#$%^&*<>[]{}|\\/"
    return chars[Math.floor(Math.random() * chars.length)]
  }, [])

  const generateGlitchLine = useCallback(() => {
    return Array(20).fill(0).map(() => randomChar()).join("")
  }, [randomChar])

  const generateHexCode = useCallback(() => {
    return "0x" + Array(8).fill(0).map(() => Math.floor(Math.random() * 16).toString(16).toUpperCase()).join("")
  }, [])

  const generateIP = useCallback(() => {
    const ips = ["185.220.101.42", "104.244.76.13", "192.42.116.16", "199.249.230.87", "94.142.244.11", "178.17.170.135"]
    return ips[Math.floor(Math.random() * ips.length)]
  }, [])

  // Matrix rain effect
  useEffect(() => {
    const columns = 15
    const initialRain = Array(columns).fill(0).map(() => 
      Array(10).fill(0).map(() => randomChar())
    )
    setMatrixRain(initialRain)

    const interval = setInterval(() => {
      setMatrixRain(prev => prev.map(column => {
        const newColumn = [...column]
        newColumn.shift()
        newColumn.push(randomChar())
        return newColumn
      }))
    }, 100)

    return () => clearInterval(interval)
  }, [randomChar])

  // Hex code animation
  useEffect(() => {
    const interval = setInterval(() => {
      setHexCode(generateHexCode())
    }, 150)
    return () => clearInterval(interval)
  }, [generateHexCode])

  // Phase 1: Initial animation - logo appears
  useEffect(() => {
    const timer1 = setTimeout(() => setShowLogo(true), 100)
    const timer2 = setTimeout(() => {
      setLogoOpacity(1)
      setLogoScale(1)
    }, 200)
    const timer3 = setTimeout(() => setPhase("decrypt"), 1500)
    
    return () => {
      clearTimeout(timer1)
      clearTimeout(timer2)
      clearTimeout(timer3)
    }
  }, [])

  // Phase 2: Decryption effect with glitch characters
  useEffect(() => {
    if (phase !== "decrypt") return

    let currentIndex = 0
    const glitchInterval = setInterval(() => {
      setGlitchChars(prev => {
        const newChars = [...prev]
        for (let i = 0; i < 3; i++) {
          newChars.push(generateGlitchLine())
        }
        if (newChars.length > 8) newChars.splice(0, 3)
        return newChars
      })
    }, 50)

    const typeInterval = setInterval(() => {
      if (currentIndex <= welcomeText.length) {
        setDisplayText(welcomeText.slice(0, currentIndex))
        currentIndex++
      } else {
        clearInterval(typeInterval)
        setTimeout(() => setPhase("welcome"), 300)
      }
    }, 80)

    return () => {
      clearInterval(glitchInterval)
      clearInterval(typeInterval)
    }
  }, [phase, generateGlitchLine])

  // Phase 3: Welcome complete, transition to loading
  useEffect(() => {
    if (phase !== "welcome") return
    
    const timer = setTimeout(() => setPhase("loading"), 800)
    return () => clearTimeout(timer)
  }, [phase])

  // Phase 4: Multi-step loading process
  useEffect(() => {
    if (phase !== "loading") return

    const processStep = async (index: number) => {
      if (index >= loadingSteps.length) {
        setTotalProgress(100)
        setTimeout(() => setPhase("complete"), 600)
        return
      }

      const step = loadingSteps[index]
      
      // Set current step to loading
      setLoadingSteps(prev => prev.map((s, i) => 
        i === index ? { ...s, status: "loading" } : s
      ))
      setCurrentStepIndex(index)
      setStepProgress(0)

      // Update IP and nodes for TOR step
      if (step.id === "tor") {
        const ipInterval = setInterval(() => {
          setIpAddress(generateIP())
          setConnectionNodes(prev => Math.min(prev + 1, 6))
        }, 200)
        setTimeout(() => clearInterval(ipInterval), step.duration)
      }

      // Animate progress for this step
      const progressInterval = setInterval(() => {
        setStepProgress(prev => {
          const newProgress = prev + (100 / (step.duration / 50))
          return Math.min(newProgress, 100)
        })
      }, 50)

      await new Promise(resolve => setTimeout(resolve, step.duration))
      clearInterval(progressInterval)

      // Mark step as complete
      setLoadingSteps(prev => prev.map((s, i) => 
        i === index ? { ...s, status: "complete" } : s
      ))
      setTotalProgress(((index + 1) / loadingSteps.length) * 100)

      // Process next step
      setTimeout(() => processStep(index + 1), 200)
    }

    processStep(0)
  }, [phase])

  // Phase 5: Complete - trigger callback
  useEffect(() => {
    if (phase !== "complete") return
    
    const timer = setTimeout(onComplete, 800)
    return () => clearTimeout(timer)
  }, [phase, onComplete])

  return (
    <div className={`fixed inset-0 z-50 bg-black flex flex-col items-center justify-center overflow-hidden transition-opacity duration-500 ${phase === "complete" ? "opacity-0" : "opacity-100"}`}>
      {/* Animated background grid */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `
            linear-gradient(rgba(255,0,0,0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,0,0,0.1) 1px, transparent 1px)
          `,
          backgroundSize: "50px 50px",
          animation: "gridMove 20s linear infinite"
        }} />
      </div>

      {/* Scanning lines */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute w-full h-[2px] bg-gradient-to-r from-transparent via-red-500/50 to-transparent animate-scan" />
        <div className="absolute w-full h-[1px] bg-gradient-to-r from-transparent via-white/30 to-transparent animate-scan-slow" />
      </div>

      {/* Glitch characters background */}
      <div className="absolute inset-0 flex flex-col justify-center items-center opacity-20 font-mono text-xs overflow-hidden">
        {glitchChars.map((line, i) => (
          <div 
            key={i} 
            className="text-red-500 whitespace-nowrap animate-pulse"
            style={{ 
              animationDelay: `${i * 0.1}s`,
              transform: `translateX(${Math.sin(i) * 20}px)`
            }}
          >
            {line}
          </div>
        ))}
      </div>

      {/* Black hole effect */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] pointer-events-none">
        <div className="absolute inset-0 rounded-full bg-gradient-radial from-transparent via-black to-black opacity-90" />
        <div className="absolute inset-[100px] rounded-full border border-white/5 animate-spin-slow" />
        <div className="absolute inset-[150px] rounded-full border border-white/10 animate-spin-slower" />
        <div className="absolute inset-[200px] rounded-full border border-red-500/10 animate-spin-slow" style={{ animationDirection: "reverse" }} />
      </div>

      {/* Main content */}
      <div className="relative z-10 flex flex-col items-center">
        {/* Logo */}
        <div 
          className="relative mb-8 transition-all duration-700 ease-out"
          style={{ 
            transform: `scale(${logoScale})`,
            opacity: logoOpacity
          }}
        >
          <div className="absolute -inset-4 bg-white/5 rounded-full blur-2xl animate-pulse" />
          <div className="absolute -inset-2 border border-white/10 rounded-full animate-spin-slow" />
          <div className="relative w-32 h-32 rounded-full overflow-hidden border-2 border-white/20 shadow-2xl shadow-white/10">
            <Image
              src="/images/spy-logo.png"
              alt="vacwerTOR"
              fill
              className="object-cover"
              priority
            />
          </div>
          {/* Glowing ring */}
          <div className="absolute -inset-1 rounded-full border border-red-500/30 animate-ping" style={{ animationDuration: "2s" }} />
        </div>

        {/* Brand name */}
        <div className="mb-6 text-center">
          <h1 className="text-3xl font-bold text-white tracking-widest mb-1">
            vacwer<span className="text-red-500">TOR</span>
          </h1>
          <div className="h-[1px] w-32 mx-auto bg-gradient-to-r from-transparent via-red-500/50 to-transparent" />
        </div>

        {/* Typing text with glitch effect */}
        <div className="h-10 flex items-center justify-center mb-8">
          <div className="relative">
            <span className="text-xl font-mono text-white tracking-[0.3em]">
              {displayText}
              {phase === "decrypt" && (
                <span className="animate-blink text-red-500">|</span>
              )}
            </span>
            {/* Glitch overlay */}
            {phase === "decrypt" && displayText.length > 0 && (
              <>
                <span 
                  className="absolute top-0 left-0 text-xl font-mono text-red-500/50 tracking-[0.3em] animate-glitch-1"
                  style={{ clipPath: "inset(0 0 50% 0)" }}
                >
                  {displayText}
                </span>
                <span 
                  className="absolute top-0 left-0 text-xl font-mono text-cyan-500/50 tracking-[0.3em] animate-glitch-2"
                  style={{ clipPath: "inset(50% 0 0 0)" }}
                >
                  {displayText}
                </span>
              </>
            )}
          </div>
        </div>

        {/* Multi-step loading */}
        {(phase === "loading" || phase === "complete") && (
          <div className="flex flex-col items-center animate-fadeIn w-full max-w-sm px-4">
            {/* Current step display */}
            <div className="text-center mb-6">
              <div className="text-white/40 text-xs font-mono mb-2 tracking-widest">
                {loadingSteps[currentStepIndex]?.text || "ГОТОВО"}
              </div>
              <div className="text-red-500/70 text-xs font-mono animate-pulse">
                {loadingSteps[currentStepIndex]?.subText || ""}
              </div>
            </div>

            {/* Hex code display */}
            <div className="text-red-500/50 text-xs font-mono mb-4 tracking-wider">
              {hexCode}
            </div>

            {/* TOR connection info */}
            {currentStepIndex >= 1 && (
              <div className="flex items-center gap-4 mb-4 text-xs font-mono">
                <div className="text-white/30">
                  IP: <span className="text-green-500/70">{ipAddress}</span>
                </div>
                <div className="text-white/30">
                  NODES: <span className="text-cyan-500/70">{connectionNodes}/6</span>
                </div>
              </div>
            )}

            {/* Total progress bar */}
            <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden mb-2">
              <div 
                className="h-full bg-gradient-to-r from-red-600 via-red-500 to-orange-500 rounded-full transition-all duration-300 relative"
                style={{ width: `${totalProgress}%` }}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer" />
              </div>
            </div>

            {/* Progress percentage */}
            <div className="text-white/50 text-xs font-mono mb-6">
              {Math.round(totalProgress)}%
            </div>

            {/* Step indicators */}
            <div className="w-full space-y-2">
              {loadingSteps.map((step, index) => (
                <div 
                  key={step.id}
                  className={`flex items-center gap-3 text-xs font-mono transition-all duration-300 ${
                    step.status === "complete" ? "text-green-500/80" :
                    step.status === "loading" ? "text-white" :
                    "text-white/20"
                  }`}
                >
                  {/* Status icon */}
                  <div className="w-4 flex justify-center">
                    {step.status === "complete" && (
                      <span className="text-green-500">[+]</span>
                    )}
                    {step.status === "loading" && (
                      <span className="text-red-500 animate-pulse">[*]</span>
                    )}
                    {step.status === "pending" && (
                      <span className="text-white/20">[ ]</span>
                    )}
                  </div>
                  
                  {/* Step text */}
                  <span className="flex-1">{step.text}</span>
                  
                  {/* Step progress */}
                  {step.status === "loading" && (
                    <span className="text-red-500/70 tabular-nums">
                      {Math.round(stepProgress)}%
                    </span>
                  )}
                  {step.status === "complete" && (
                    <span className="text-green-500/50">OK</span>
                  )}
                </div>
              ))}
            </div>

            {/* Matrix rain columns */}
            <div className="absolute bottom-20 left-0 right-0 flex justify-around opacity-10 overflow-hidden h-32 pointer-events-none">
              {matrixRain.map((column, colIndex) => (
                <div key={colIndex} className="flex flex-col text-green-500 font-mono text-xs">
                  {column.map((char, charIndex) => (
                    <span 
                      key={charIndex}
                      style={{ opacity: (charIndex + 1) / column.length }}
                    >
                      {char}
                    </span>
                  ))}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Corner decorations */}
      <div className="absolute top-4 left-4 text-red-500/30 font-mono text-xs">
        <div>SYS://INIT</div>
        <div className="text-white/20">v2.0.4</div>
      </div>
      <div className="absolute top-4 right-4 text-white/20 font-mono text-xs text-right">
        <div>SECURE</div>
        <div className="text-green-500/50">ACTIVE</div>
      </div>
      <div className="absolute bottom-4 left-4 text-white/10 font-mono text-xs">
        {new Date().toISOString().split("T")[0]}
      </div>
      <div className="absolute bottom-4 right-4 text-white/10 font-mono text-xs">
        TOR://CONNECTED
      </div>

      <style jsx>{`
        @keyframes gridMove {
          0% { transform: translate(0, 0); }
          100% { transform: translate(50px, 50px); }
        }
        @keyframes scan {
          0% { top: -10%; opacity: 0; }
          50% { opacity: 1; }
          100% { top: 110%; opacity: 0; }
        }
        @keyframes scan-slow {
          0% { top: -10%; opacity: 0; }
          50% { opacity: 0.5; }
          100% { top: 110%; opacity: 0; }
        }
        .animate-scan {
          animation: scan 3s ease-in-out infinite;
        }
        .animate-scan-slow {
          animation: scan-slow 5s ease-in-out infinite;
          animation-delay: 1s;
        }
        .animate-spin-slow {
          animation: spin 20s linear infinite;
        }
        .animate-spin-slower {
          animation: spin 30s linear infinite;
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-blink {
          animation: blink 0.7s infinite;
        }
        @keyframes blink {
          0%, 100% { opacity: 1; }
          50% { opacity: 0; }
        }
        .animate-glitch-1 {
          animation: glitch-1 0.3s infinite;
        }
        .animate-glitch-2 {
          animation: glitch-2 0.3s infinite;
          animation-delay: 0.1s;
        }
        .animate-fadeIn {
          animation: fadeIn 0.5s ease-out;
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        @keyframes glitch-1 {
          0%, 100% { transform: translateX(0); }
          20% { transform: translateX(-2px); }
          40% { transform: translateX(2px); }
          60% { transform: translateX(-1px); }
          80% { transform: translateX(1px); }
        }
        @keyframes glitch-2 {
          0%, 100% { transform: translateX(0); }
          20% { transform: translateX(2px); }
          40% { transform: translateX(-2px); }
          60% { transform: translateX(1px); }
          80% { transform: translateX(-1px); }
        }
        .animate-shimmer {
          animation: shimmer 1.5s infinite;
        }
        .animate-glitch-1 {
          animation: glitch-1 0.3s infinite;
        }
        .animate-glitch-2 {
          animation: glitch-2 0.3s infinite;
          animation-delay: 0.1s;
        }
        .bg-gradient-radial {
          background: radial-gradient(circle, var(--tw-gradient-stops));
        }
      `}</style>
    </div>
  )
}
