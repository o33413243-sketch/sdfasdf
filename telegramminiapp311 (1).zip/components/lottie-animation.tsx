"use client"

import { useEffect, useRef, useState, useCallback } from "react"

interface LottieAnimationProps {
  src: string
  loop?: boolean
  autoplay?: boolean
  className?: string
}

export function LottieAnimation({ src, loop = true, autoplay = true, className = "" }: LottieAnimationProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const animationRef = useRef<ReturnType<typeof import("lottie-web").default.loadAnimation> | null>(null)
  const [isLoaded, setIsLoaded] = useState(false)
  const [error, setError] = useState(false)
  const [retryCount, setRetryCount] = useState(0)

  const loadAnimation = useCallback(async () => {
    if (!containerRef.current) return

    try {
      const lottie = (await import("lottie-web")).default

      const response = await fetch(src, {
        cache: "force-cache",
        headers: {
          Accept: "application/json",
        },
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const text = await response.text()
      
      // Check if response starts with HTML (error page)
      if (text.trim().startsWith("<!") || text.trim().startsWith("<html")) {
        throw new Error("Response is HTML, not JSON")
      }

      const animationData = JSON.parse(text)

      if (!containerRef.current) return

      if (animationRef.current) {
        animationRef.current.destroy()
        animationRef.current = null
      }

      containerRef.current.innerHTML = ""

      animationRef.current = lottie.loadAnimation({
        container: containerRef.current,
        renderer: "canvas",
        loop,
        autoplay,
        animationData,
        rendererSettings: {
          preserveAspectRatio: "xMidYMid meet",
          clearCanvas: true,
          progressiveLoad: false,
        },
      })

      animationRef.current.addEventListener("DOMLoaded", () => {
        setIsLoaded(true)
      })

      setTimeout(() => {
        setIsLoaded(true)
      }, 500)
    } catch (err) {
      if (retryCount < 2) {
        setTimeout(() => {
          setRetryCount((c) => c + 1)
        }, 1000)
      } else {
        setError(true)
      }
    }
  }, [src, loop, autoplay, retryCount])

  useEffect(() => {
    loadAnimation()

    return () => {
      if (animationRef.current) {
        animationRef.current.destroy()
        animationRef.current = null
      }
    }
  }, [loadAnimation])

  if (error) {
    return (
      <div className={`${className} flex items-center justify-center bg-white/10 rounded-full`}>
        <div className="w-1/2 h-1/2 bg-gradient-to-br from-white/30 to-white/10 rounded-full" />
      </div>
    )
  }

  return (
    <div
      ref={containerRef}
      className={`${className} ${!isLoaded ? "animate-pulse bg-white/5 rounded-full" : ""}`}
      style={{
        minWidth: "40px",
        minHeight: "40px",
        touchAction: "none",
        WebkitTapHighlightColor: "transparent",
      }}
    />
  )
}
