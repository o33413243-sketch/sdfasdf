"use client"

import { TrendingUp, Shield, AlertTriangle, Search } from "lucide-react"
import { LottieAnimation } from "./lottie-animation"
import { ANIMATIONS } from "@/lib/animations"

interface StatsViewProps {
  stats: {
    blocked: number
    alerts: number
    scans: number
  }
}

export function StatsView({ stats }: StatsViewProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-white font-bold text-xl">Статистика защиты</h2>
        <div className="w-16 h-16 flex-shrink-0">
          <LottieAnimation src={ANIMATIONS.electricSkull} className="w-full h-full" />
        </div>
      </div>

      <div className="grid gap-3">
        <div className="p-4 bg-black/40 backdrop-blur-md rounded-2xl border border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-green-500/20 flex items-center justify-center">
              <Shield className="w-5 h-5 text-green-400" />
            </div>
            <div className="flex-1">
              <div className="text-white/50 text-sm">Угроз заблокировано</div>
              <div className="text-white font-bold text-2xl">{stats.blocked}</div>
            </div>
            <TrendingUp className="w-5 h-5 text-green-400" />
          </div>
        </div>

        <div className="p-4 bg-black/40 backdrop-blur-md rounded-2xl border border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-yellow-500/20 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-yellow-400" />
            </div>
            <div className="flex-1">
              <div className="text-white/50 text-sm">Оповещения безопасности</div>
              <div className="text-white font-bold text-2xl">{stats.alerts}</div>
            </div>
            <LottieAnimation src={ANIMATIONS.scaredCat} className="w-10 h-10" />
          </div>
        </div>

        <div className="p-4 bg-black/40 backdrop-blur-md rounded-2xl border border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center">
              <Search className="w-5 h-5 text-blue-400" />
            </div>
            <div className="flex-1">
              <div className="text-white/50 text-sm">Обнаружено сканирований</div>
              <div className="text-white font-bold text-2xl">{stats.scans}</div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-6 p-4 bg-white/5 rounded-2xl border border-white/10">
        <div className="flex items-center justify-center gap-4">
          <LottieAnimation src={ANIMATIONS.magicPotion} className="w-10 h-10 opacity-70" />
          <div className="text-white/70 text-sm text-center">
            Ваш профиль мониторится 24/7
            <br />
            <span className="text-white/40">Последняя проверка: только что</span>
          </div>
        </div>
      </div>

      <div className="flex justify-center gap-4 mt-4">
        <LottieAnimation src={ANIMATIONS.plushPepe} className="w-12 h-12 opacity-50" />
        <LottieAnimation src={ANIMATIONS.perfumeBottle} className="w-12 h-12 opacity-50" />
        <LottieAnimation src={ANIMATIONS.durovCap} className="w-12 h-12 opacity-50" />
      </div>
    </div>
  )
}
