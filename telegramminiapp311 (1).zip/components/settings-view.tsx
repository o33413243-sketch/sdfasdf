"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Bell, Moon, Sun, Palette, Globe, Info, LogOut, Check, Upload, X } from "lucide-react"
import { LottieAnimation } from "./lottie-animation"
import { ANIMATIONS } from "@/lib/animations"
import { useTheme } from "./theme-provider"

interface SettingsViewProps {
  isProtectionEnabled: boolean
  onDisableProtection: () => void
  isDisabling?: boolean
}

export function SettingsView({ isProtectionEnabled, onDisableProtection, isDisabling }: SettingsViewProps) {
  const { theme, setTheme, customTheme, setCustomTheme } = useTheme()
  const [showThemeModal, setShowThemeModal] = useState(false)
  const [showCustomModal, setShowCustomModal] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, type: "background" | "card") => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        const imageUrl = event.target?.result as string
        if (type === "background") {
          setCustomTheme({ ...customTheme, backgroundImage: imageUrl })
        }
      }
      reader.readAsDataURL(file)
    }
  }

  const themes = [
    { id: "dark" as const, icon: Moon, label: "Темная", description: "Черно-белый космос" },
    { id: "light" as const, icon: Sun, label: "Светлая", description: "Белый минимализм" },
    { id: "custom" as const, icon: Palette, label: "Кастомная", description: "Своя настройка" },
  ]

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-white font-bold text-xl">Настройки</h2>
        <LottieAnimation src={ANIMATIONS.durovCap} className="w-14 h-14" />
      </div>

      {/* Theme Selector */}
      <div
        onClick={() => setShowThemeModal(true)}
        className="flex items-center justify-between p-4 bg-black/40 backdrop-blur-md rounded-2xl border border-white/10 cursor-pointer hover:border-white/20 transition-colors"
      >
        <div className="flex items-center gap-3">
          <Moon className="w-5 h-5 text-white/50" />
          <span className="text-white">Тема оформления</span>
        </div>
        <span className="text-white/40">
          {theme === "dark" ? "Темная" : theme === "light" ? "Светлая" : "Кастомная"}
        </span>
      </div>

      {/* Other Settings */}
      <div className="space-y-2">
        <div className="flex items-center justify-between p-4 bg-black/40 backdrop-blur-md rounded-2xl border border-white/10">
          <div className="flex items-center gap-3">
            <Bell className="w-5 h-5 text-white/50" />
            <span className="text-white">Уведомления</span>
          </div>
          <span className="text-white/40">Вкл</span>
        </div>

        <div className="flex items-center justify-between p-4 bg-black/40 backdrop-blur-md rounded-2xl border border-white/10">
          <div className="flex items-center gap-3">
            <Globe className="w-5 h-5 text-white/50" />
            <span className="text-white">Язык</span>
          </div>
          <span className="text-white/40">Русский</span>
        </div>

        <div className="flex items-center justify-between p-4 bg-black/40 backdrop-blur-md rounded-2xl border border-white/10">
          <div className="flex items-center gap-3">
            <Info className="w-5 h-5 text-white/50" />
            <span className="text-white">Версия</span>
          </div>
          <span className="text-white/40">1.0.0</span>
        </div>
      </div>

      {/* Disable Protection Button */}
      {isProtectionEnabled && (
        <button
          onClick={onDisableProtection}
          disabled={isDisabling}
          className="w-full mt-4 p-4 bg-red-500/10 rounded-2xl border border-red-500/20 flex items-center justify-center gap-2 text-red-400 hover:bg-red-500/20 transition-colors disabled:opacity-50"
        >
          {isDisabling ? (
            <div className="w-5 h-5 border-2 border-red-400/30 border-t-red-400 rounded-full animate-spin" />
          ) : (
            <LogOut className="w-5 h-5" />
          )}
          <span>{isDisabling ? "Отключение..." : "Отключить защиту"}</span>
        </button>
      )}

      {/* Theme Modal */}
      {showThemeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm bg-black/90 rounded-2xl border border-white/20 p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-bold text-lg">Выбор темы</h3>
              <button onClick={() => setShowThemeModal(false)} className="p-2 hover:bg-white/10 rounded-full">
                <X className="w-5 h-5 text-white/50" />
              </button>
            </div>

            <div className="space-y-2">
              {themes.map((t) => {
                const Icon = t.icon
                return (
                  <button
                    key={t.id}
                    onClick={() => {
                      if (t.id === "custom") {
                        setShowThemeModal(false)
                        setShowCustomModal(true)
                      } else {
                        setTheme(t.id)
                        setShowThemeModal(false)
                      }
                    }}
                    className={`w-full p-4 rounded-xl flex items-center justify-between transition-colors ${
                      theme === t.id
                        ? "bg-white/20 border border-white/30"
                        : "bg-white/5 border border-white/10 hover:bg-white/10"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="w-5 h-5 text-white" />
                      <div className="text-left">
                        <div className="text-white font-medium">{t.label}</div>
                        <div className="text-white/50 text-sm">{t.description}</div>
                      </div>
                    </div>
                    {theme === t.id && <Check className="w-5 h-5 text-green-400" />}
                  </button>
                )
              })}
            </div>
          </div>
        </div>
      )}

      {/* Custom Theme Modal */}
      {showCustomModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm bg-black/90 rounded-2xl border border-white/20 p-4 max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-bold text-lg">Кастомная тема</h3>
              <button onClick={() => setShowCustomModal(false)} className="p-2 hover:bg-white/10 rounded-full">
                <X className="w-5 h-5 text-white/50" />
              </button>
            </div>

            <div className="space-y-4">
              {/* Background Image Upload */}
              <div>
                <label className="text-white/70 text-sm mb-2 block">Фон приложения</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleImageUpload(e, "background")}
                  className="hidden"
                  ref={fileInputRef}
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full p-4 rounded-xl border border-dashed border-white/20 flex items-center justify-center gap-2 text-white/50 hover:bg-white/5 transition-colors"
                >
                  <Upload className="w-5 h-5" />
                  <span>Загрузить изображение</span>
                </button>
                {customTheme.backgroundImage && (
                  <div className="mt-2 relative">
                    <img
                      src={customTheme.backgroundImage || "/placeholder.svg"}
                      alt="Background preview"
                      className="w-full h-20 object-cover rounded-lg"
                    />
                    <button
                      onClick={() => setCustomTheme({ ...customTheme, backgroundImage: undefined })}
                      className="absolute top-1 right-1 p-1 bg-black/50 rounded-full"
                    >
                      <X className="w-4 h-4 text-white" />
                    </button>
                  </div>
                )}
              </div>

              {/* Accent Color */}
              <div>
                <label className="text-white/70 text-sm mb-2 block">Цвет акцента</label>
                <div className="flex gap-2">
                  {["#ffffff", "#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6"].map((color) => (
                    <button
                      key={color}
                      onClick={() => setCustomTheme({ ...customTheme, accentColor: color })}
                      className={`w-10 h-10 rounded-full border-2 transition-transform ${
                        customTheme.accentColor === color ? "border-white scale-110" : "border-transparent"
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>

              <button
                onClick={() => {
                  setTheme("custom")
                  setShowCustomModal(false)
                }}
                className="w-full py-3 bg-white text-black rounded-xl font-semibold hover:bg-white/90 transition-colors"
              >
                Применить
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
