"use client"

import { useState, useEffect } from "react"
import { Clock, Shield, Star, ChevronRight, Sparkles } from "lucide-react"
import { LottieAnimation } from "./lottie-animation"
import { ANIMATIONS } from "@/lib/animations"

interface StandardProtectionCardProps {
  onActivate?: () => void
}

export function StandardProtectionCard({ onActivate }: StandardProtectionCardProps) {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  })
  const [isExpanded, setIsExpanded] = useState(false)

  // Timer until 30.01.2026 20:00
  useEffect(() => {
    const targetDate = new Date("2026-01-30T20:00:00").getTime()

    const updateTimer = () => {
      const now = new Date().getTime()
      const difference = targetDate - now

      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((difference % (1000 * 60)) / 1000),
        })
      }
    }

    updateTimer()
    const interval = setInterval(updateTimer, 1000)

    return () => clearInterval(interval)
  }, [])

  // Array of animations to display
  const animations = [
    { src: ANIMATIONS.electricSkull, label: "Skull Guard" },
    { src: ANIMATIONS.magicPotion, label: "Magic Shield" },
    { src: ANIMATIONS.scaredCat, label: "Alert System" },
  ]

  return (
    <div className="relative mt-4">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full p-4 bg-gradient-to-br from-gray-900/80 to-black/60 backdrop-blur-md rounded-2xl border-2 border-white/20 text-left transition-all hover:border-white/40 hover:scale-[1.02]"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* Animated icon */}
            <div className="relative w-14 h-14 flex-shrink-0">
              <LottieAnimation src={ANIMATIONS.electricSkull} className="w-14 h-14" />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-white font-bold text-lg">Стандартная защита</h3>
                <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
              </div>
              <p className="text-white/50 text-sm">Скоро доступно</p>
            </div>
          </div>

          <ChevronRight className={`w-5 h-5 text-white/50 transition-transform ${isExpanded ? "rotate-90" : ""}`} />
        </div>

        {/* Timer */}
        <div className="mt-4 p-3 bg-black/40 rounded-xl border border-white/10">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-4 h-4 text-white/50" />
            <span className="text-white/50 text-xs">До открытия:</span>
          </div>
          <div className="grid grid-cols-4 gap-2 text-center">
            <div className="bg-white/5 rounded-lg p-2">
              <div className="text-white font-bold text-xl">{timeLeft.days}</div>
              <div className="text-white/40 text-xs">дней</div>
            </div>
            <div className="bg-white/5 rounded-lg p-2">
              <div className="text-white font-bold text-xl">{timeLeft.hours}</div>
              <div className="text-white/40 text-xs">часов</div>
            </div>
            <div className="bg-white/5 rounded-lg p-2">
              <div className="text-white font-bold text-xl">{timeLeft.minutes}</div>
              <div className="text-white/40 text-xs">минут</div>
            </div>
            <div className="bg-white/5 rounded-lg p-2">
              <div className="text-white font-bold text-xl">{timeLeft.seconds}</div>
              <div className="text-white/40 text-xs">секунд</div>
            </div>
          </div>
        </div>

        {/* Trial period badge */}
        <div className="mt-3 flex items-center gap-2 bg-green-500/10 px-3 py-2 rounded-lg border border-green-500/20">
          <Sparkles className="w-4 h-4 text-green-400" />
          <span className="text-green-400 text-sm font-medium">Пробный период 7 дней бесплатно!</span>
        </div>
      </button>

      {/* Expanded content */}
      {isExpanded && (
        <div className="mt-2 p-4 bg-black/60 backdrop-blur-md rounded-2xl border border-white/20 animate-in slide-in-from-top-2 duration-200">
          {/* Animation showcase */}
          <div className="flex justify-around items-center mb-4 py-2">
            {animations.map((anim, index) => (
              <div key={index} className="flex flex-col items-center">
                <LottieAnimation src={anim.src} className="w-16 h-16" />
                <span className="text-white/40 text-xs mt-1">{anim.label}</span>
              </div>
            ))}
          </div>

          <div className="flex items-center gap-3 mb-4">
            <LottieAnimation src={ANIMATIONS.magicPotion} className="w-12 h-12" />
            <div>
              <h4 className="text-white font-semibold">Премиум функции</h4>
              <p className="text-white/50 text-sm">Расширенная защита</p>
            </div>
          </div>

          <div className="space-y-3 mb-4">
            <div className="flex items-center gap-3 text-white/70">
              <Shield className="w-4 h-4 flex-shrink-0 text-blue-400" />
              <span className="text-sm">Расширенная защита от всех типов OSINT</span>
            </div>
            <div className="flex items-center gap-3 text-white/70">
              <Shield className="w-4 h-4 flex-shrink-0 text-purple-400" />
              <span className="text-sm">Мониторинг даркнета на утечки данных</span>
            </div>
            <div className="flex items-center gap-3 text-white/70">
              <Shield className="w-4 h-4 flex-shrink-0 text-green-400" />
              <span className="text-sm">Приоритетные уведомления и поддержка 24/7</span>
            </div>
            <div className="flex items-center gap-3 text-white/70">
              <Shield className="w-4 h-4 flex-shrink-0 text-yellow-400" />
              <span className="text-sm">VPN защита и анонимизация трафика</span>
            </div>
          </div>

          <div className="p-3 bg-white/5 rounded-xl border border-white/10 text-center">
            <div className="text-white/40 text-xs mb-1">После запуска</div>
            <div className="text-white font-bold text-lg">7 дней бесплатно</div>
            <div className="text-white/50 text-sm">потом от 99 RUB/мес</div>
          </div>

          {/* Coming soon button */}
          <button
            disabled
            className="w-full mt-4 py-3 rounded-xl font-semibold bg-white/10 text-white/50 cursor-not-allowed border border-white/10"
          >
            Доступно с 30.01.2026
          </button>
        </div>
      )}
    </div>
  )
}
