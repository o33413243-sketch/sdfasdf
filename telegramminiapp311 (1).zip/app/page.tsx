"use client"

import { useEffect, useState } from "react"
import { useTelegram } from "@/hooks/use-telegram"
import { StarField } from "@/components/star-field"
import { BlackHole } from "@/components/black-hole"
import { UserProfile } from "@/components/user-profile"
import { ProtectionCard } from "@/components/protection-card"
import { StandardProtectionCard } from "@/components/standard-protection-card"
import { BottomNavigation } from "@/components/bottom-navigation"
import { StatsView } from "@/components/stats-view"
import { SettingsView } from "@/components/settings-view"
import { ThemeProvider, useTheme } from "@/components/theme-provider"
import { LottieAnimation } from "@/components/lottie-animation"
import { SplashScreen } from "@/components/splash-screen"
import { ANIMATIONS } from "@/lib/animations"
import type { DBUser } from "@/types/telegram"

function AppContent() {
  const { user, isReady, hapticFeedback, showAlert } = useTelegram()
  const [activeTab, setActiveTab] = useState("home")
  const [dbUser, setDbUser] = useState<DBUser | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isDisabling, setIsDisabling] = useState(false)
  const [showSplash, setShowSplash] = useState(true)
  const { theme, customTheme } = useTheme()

  // Sync user with database
  useEffect(() => {
    async function syncUser() {
      if (!user) {
        setIsLoading(false)
        return
      }

      try {
        const getResponse = await fetch(`/api/user?id=${user.id}`)
        const getData = await getResponse.json()

        if (getData.user) {
          setDbUser(getData.user)
        } else {
          const postResponse = await fetch("/api/user", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              id: user.id,
              username: user.username,
              first_name: user.first_name,
              last_name: user.last_name,
              photo_url: user.photo_url,
              is_premium: user.is_premium,
            }),
          })
          const postData = await postResponse.json()
          setDbUser(postData.user)
        }
      } catch (error) {
        console.error("Error syncing user:", error)
      } finally {
        setIsLoading(false)
      }
    }

    if (isReady) {
      syncUser()
    }
  }, [user, isReady])

  const handleConnect = async () => {
    hapticFeedback("heavy")

    if (!user) {
      showAlert("Пожалуйста, откройте приложение через Telegram")
      return
    }

    try {
      const response = await fetch("/api/protection", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.id,
          enabled: true,
          chatId: user.id,
        }),
      })

      const data = await response.json()

      if (data.success) {
        setDbUser(data.user)
        hapticFeedback("success")
        showAlert(data.message)
      }
    } catch (error) {
      console.error("Error enabling protection:", error)
      hapticFeedback("error")
      showAlert("Ошибка активации защиты. Попробуйте снова.")
    }
  }

  const handleDisconnect = async () => {
    hapticFeedback("heavy")
    setIsDisabling(true)

    if (!user) {
      showAlert("Пожалуйста, откройте приложение через Telegram")
      setIsDisabling(false)
      return
    }

    try {
      const response = await fetch("/api/protection", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.id,
          enabled: false,
          chatId: user.id,
        }),
      })

      const data = await response.json()

      if (data.success) {
        setDbUser(data.user)
        hapticFeedback("warning")
        showAlert("Защита отключена")
      }
    } catch (error) {
      console.error("Error disabling protection:", error)
      hapticFeedback("error")
      showAlert("Ошибка отключения защиты. Попробуйте снова.")
    } finally {
      setIsDisabling(false)
    }
  }

  const handleTabChange = (tab: string) => {
    hapticFeedback("light")
    setActiveTab(tab)
  }

  const stats = dbUser?.protection_stats || { blocked: 0, alerts: 0, scans: 0 }
  const isProtectionEnabled = dbUser?.protection_enabled || false

  const backgroundStyle =
    theme === "custom" && customTheme.backgroundImage
      ? {
          backgroundImage: `url(${customTheme.backgroundImage})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }
      : {}

  const renderContent = () => {
    switch (activeTab) {
      case "home":
        return (
          <div className="space-y-4">
            <UserProfile user={user} isOnline={isReady} />

            <ProtectionCard
              isEnabled={isProtectionEnabled}
              onConnect={handleConnect}
              onDisconnect={handleDisconnect}
              stats={stats}
              isLoading={isLoading}
            />

            <StandardProtectionCard />

            <div className="grid grid-cols-2 gap-3 mt-4">
              <div className="p-4 bg-black/40 backdrop-blur-md rounded-2xl border border-white/10 text-center relative overflow-hidden">
                <div className="absolute -top-2 -right-2 opacity-30">
                  <LottieAnimation src={ANIMATIONS.scaredCat} className="w-16 h-16" />
                </div>
                <div className="text-3xl font-bold text-white relative z-10">{stats.blocked}</div>
                <div className="text-white/50 text-xs mt-1 relative z-10">Угроз заблокировано</div>
              </div>
              <div className="p-4 bg-black/40 backdrop-blur-md rounded-2xl border border-white/10 text-center relative overflow-hidden">
                <div className="absolute -top-2 -right-2 opacity-30">
                  <LottieAnimation src={ANIMATIONS.perfumeBottle} className="w-16 h-16" />
                </div>
                <div className="text-3xl font-bold text-white relative z-10">{stats.scans}</div>
                <div className="text-white/50 text-xs mt-1 relative z-10">Сканирований</div>
              </div>
            </div>

            <div className="flex items-center justify-center gap-3 mt-6 opacity-50">
              <LottieAnimation src={ANIMATIONS.magicPotion} className="w-6 h-6" />
              <span className="text-white/40 text-xs">Защита цифровой личности</span>
            </div>
          </div>
        )
      case "protection":
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-white font-bold text-xl">Защита профиля</h2>
              <LottieAnimation src={ANIMATIONS.plushPepe} className="w-14 h-14" />
            </div>
            <ProtectionCard
              isEnabled={isProtectionEnabled}
              onConnect={handleConnect}
              onDisconnect={handleDisconnect}
              stats={stats}
              isLoading={isLoading}
            />
            <StandardProtectionCard />
          </div>
        )
      case "stats":
        return <StatsView stats={stats} />
      case "settings":
        return (
          <SettingsView
            isProtectionEnabled={isProtectionEnabled}
            onDisableProtection={handleDisconnect}
            isDisabling={isDisabling}
          />
        )
      default:
        return null
    }
  }

  if (showSplash) {
    return (
      <SplashScreen 
        onComplete={() => setShowSplash(false)} 
        username={user?.username}
      />
    )
  }

  return (
    <div
      className={`min-h-screen text-white overflow-hidden relative ${theme === "light" ? "bg-gray-100" : "bg-black"}`}
      style={backgroundStyle}
    >
      {theme !== "custom" && <StarField />}

      <div className="relative z-10 px-4 pt-4 pb-32 pointer-events-auto">
        <div className="flex justify-center mb-4">
          <BlackHole />
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div
              className={`w-8 h-8 border-2 ${theme === "light" ? "border-black/20 border-t-black" : "border-white/20 border-t-white"} rounded-full animate-spin`}
            />
          </div>
        ) : (
          renderContent()
        )}
      </div>

      <BottomNavigation activeTab={activeTab} onTabChange={handleTabChange} />
    </div>
  )
}

export default function TelegramMiniApp() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  )
}
