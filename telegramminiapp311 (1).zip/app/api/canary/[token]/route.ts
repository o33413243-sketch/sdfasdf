// Canary Token Handler - Triggers alert when accessed
import { NextResponse } from 'next/server'
import { handleCanaryAccess } from '@/lib/osint-detector'

export async function GET(
  request: Request,
  { params }: { params: Promise<{ token: string }> }
) {
  const { token } = await params
  
  // Get visitor info
  const ipAddress = request.headers.get('x-forwarded-for')?.split(',')[0] || 
                    request.headers.get('x-real-ip') || 
                    'unknown'
  const userAgent = request.headers.get('user-agent') || undefined
  const referer = request.headers.get('referer') || undefined
  
  // Handle canary access - this sends alert to user
  await handleCanaryAccess(token, ipAddress, userAgent, referer)
  
  // Return a 1x1 transparent pixel (to work as tracking pixel)
  const pixel = Buffer.from(
    'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
    'base64'
  )
  
  return new NextResponse(pixel, {
    headers: {
      'Content-Type': 'image/gif',
      'Cache-Control': 'no-store, no-cache, must-revalidate',
    },
  })
}
