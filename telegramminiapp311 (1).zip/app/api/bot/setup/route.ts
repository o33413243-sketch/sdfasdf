import { NextResponse } from "next/server"

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || ""

export async function GET(request: Request) {
  try {
    const url = new URL(request.url)
    const webhookUrl = `${url.origin}/api/telegram/webhook`

    // Удаляем старый webhook
    await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/deleteWebhook`)

    // Устанавливаем новый webhook
    const setWebhookResponse = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/setWebhook`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url: webhookUrl,
        allowed_updates: ["message", "callback_query"],
        drop_pending_updates: true,
      }),
    })
    const setWebhookResult = await setWebhookResponse.json()

    // Получаем информацию о боте
    const getMeResponse = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/getMe`)
    const getMeResult = await getMeResponse.json()

    // Получаем текущий webhook info
    const getWebhookResponse = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/getWebhookInfo`)
    const getWebhookResult = await getWebhookResponse.json()

    // Устанавливаем команды бота
    await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/setMyCommands`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        commands: [
          { command: "start", description: "Запустить бота" },
          { command: "help", description: "Помощь" },
          { command: "status", description: "Статус защиты" },
          { command: "menu", description: "Показать меню" },
          { command: "admin", description: "Админ панель" },
        ],
      }),
    })

    // Возвращаем HTML страницу с информацией
    const botUsername = getMeResult.result?.username || "vacwerTOR_bot"
    const isSuccess = setWebhookResult.ok && getWebhookResult.result?.url === webhookUrl

    const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>vacwerTOR Bot Setup</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: linear-gradient(135deg, #000 0%, #1a1a2e 100%);
      min-height: 100vh;
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .container {
      max-width: 500px;
      width: 100%;
      background: rgba(255,255,255,0.05);
      border-radius: 20px;
      padding: 40px;
      border: 1px solid rgba(255,255,255,0.1);
      backdrop-filter: blur(10px);
    }
    .logo {
      text-align: center;
      margin-bottom: 30px;
    }
    .logo h1 {
      font-size: 32px;
      margin-bottom: 5px;
    }
    .logo p {
      color: rgba(255,255,255,0.5);
    }
    .status {
      background: ${isSuccess ? "rgba(34,197,94,0.2)" : "rgba(239,68,68,0.2)"};
      border: 1px solid ${isSuccess ? "rgba(34,197,94,0.3)" : "rgba(239,68,68,0.3)"};
      border-radius: 12px;
      padding: 20px;
      text-align: center;
      margin-bottom: 20px;
    }
    .status-icon {
      font-size: 48px;
      margin-bottom: 10px;
    }
    .status h2 {
      color: ${isSuccess ? "#22c55e" : "#ef4444"};
    }
    .info {
      background: rgba(255,255,255,0.05);
      border-radius: 12px;
      padding: 15px;
      margin-bottom: 15px;
    }
    .info-row {
      display: flex;
      justify-content: space-between;
      padding: 8px 0;
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    .info-row:last-child {
      border-bottom: none;
    }
    .info-label {
      color: rgba(255,255,255,0.5);
    }
    .info-value {
      color: white;
      font-weight: 500;
      word-break: break-all;
    }
    .btn {
      display: block;
      width: 100%;
      padding: 15px;
      border: none;
      border-radius: 12px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      text-decoration: none;
      text-align: center;
      margin-top: 10px;
      transition: transform 0.2s;
    }
    .btn:hover {
      transform: scale(1.02);
    }
    .btn-primary {
      background: white;
      color: black;
    }
    .btn-secondary {
      background: rgba(255,255,255,0.1);
      color: white;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="logo">
      <h1>🛡 vacwerTOR</h1>
      <p>Bot Setup Panel</p>
    </div>
    
    <div class="status">
      <div class="status-icon">${isSuccess ? "✅" : "❌"}</div>
      <h2>${isSuccess ? "Бот настроен!" : "Ошибка настройки"}</h2>
      <p>${isSuccess ? "Webhook успешно установлен" : "Проверьте токен бота"}</p>
    </div>
    
    <div class="info">
      <div class="info-row">
        <span class="info-label">Бот</span>
        <span class="info-value">@${botUsername}</span>
      </div>
      <div class="info-row">
        <span class="info-label">Webhook URL</span>
        <span class="info-value">${webhookUrl}</span>
      </div>
      <div class="info-row">
        <span class="info-label">Статус</span>
        <span class="info-value">${isSuccess ? "🟢 Активен" : "🔴 Неактивен"}</span>
      </div>
    </div>
    
    <a href="https://t.me/${botUsername}" class="btn btn-primary" target="_blank">
      📱 Открыть бота в Telegram
    </a>
    <a href="/" class="btn btn-secondary">
      ← Вернуться в приложение
    </a>
  </div>
</body>
</html>
`

    return new Response(html, {
      headers: { "Content-Type": "text/html" },
    })
  } catch (error) {
    console.error("Bot setup error:", error)
    return NextResponse.json({ error: "Failed to setup bot" }, { status: 500 })
  }
}
