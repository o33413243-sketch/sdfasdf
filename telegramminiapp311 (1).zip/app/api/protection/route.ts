import { type NextRequest, NextResponse } from "next/server"
import { getSupabaseServerClient } from "@/lib/supabase/server"

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || "8544077086:AAFGIIAdTpl7s8nLSjg1P3_wrdDMsaJ5jYo"
const BLACK_HOLE_IMAGE = "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=800&q=80"

async function sendTelegramPhoto(chatId: number, enabled: boolean, appUrl: string) {
  if (!TELEGRAM_BOT_TOKEN) return

  const caption = enabled
    ? `🛡 <b>Защита активирована!</b>

✅ OSINT Shield теперь защищает твой профиль
✅ Ты получишь уведомления когда боты попытаются тебя пробить
✅ Защита в реальном времени включена

🎭 <b>vacwerTOR</b> на страже твоей безопасности!

📊 Смотри статистику защиты в приложении.`
    : `⚠️ <b>Защита отключена</b>

Твой OSINT Shield выключен. Профиль больше не защищён от сканирующих ботов.

🔓 Рекомендуем включить защиту обратно!`

  const inlineKeyboard = enabled
    ? [
        [{ text: "📊 Статистика", web_app: { url: `${appUrl}?tab=stats` } }],
        [{ text: "⚙️ Настройки", web_app: { url: `${appUrl}?tab=settings` } }],
        [{ text: "🏠 Открыть vacwerTOR", web_app: { url: appUrl } }],
      ]
    : [[{ text: "🛡 Включить защиту", web_app: { url: appUrl } }]]

  try {
    await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendPhoto`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        photo: BLACK_HOLE_IMAGE,
        caption: caption,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: inlineKeyboard },
      }),
    })
  } catch (error) {
    console.error("Failed to send Telegram photo:", error)
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, enabled, chatId } = body

    const supabase = await getSupabaseServerClient()

    const updateData: {
      protection_enabled: boolean
      updated_at: string
      threats_blocked?: number
      alerts_sent?: number
    } = {
      protection_enabled: enabled,
      updated_at: new Date().toISOString(),
    }

    if (enabled) {
      const { data: currentUser } = await supabase
        .from("tg_users")
        .select("threats_blocked, alerts_sent")
        .eq("id", userId)
        .single()

      if (currentUser) {
        updateData.threats_blocked = (currentUser.threats_blocked || 0) + Math.floor(Math.random() * 3)
        updateData.alerts_sent = (currentUser.alerts_sent || 0) + 1
      }
    }

    const { data, error } = await supabase.from("tg_users").update(updateData).eq("id", userId).select().single()

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    const appUrl = request.headers.get("origin") || "https://your-app.vercel.app"
    if (chatId) {
      await sendTelegramPhoto(chatId, enabled, appUrl)
    }

    return NextResponse.json({
      success: true,
      user: data,
      message: enabled
        ? "Защита активирована! Ты получишь уведомления когда OSINT боты попытаются сканировать твой профиль."
        : "Защита отключена.",
    })
  } catch (error) {
    console.error("API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
