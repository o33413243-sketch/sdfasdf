// OSINT Intercept API - Receives notifications from monitoring systems
import { NextResponse } from 'next/server'
import { detectOSINTQuery } from '@/lib/osint-detector'

// Secret key for webhook authentication
const WEBHOOK_SECRET = process.env.OSINT_WEBHOOK_SECRET

export async function POST(request: Request) {
  try {
    // Verify webhook secret
    const authHeader = request.headers.get('authorization')
    if (WEBHOOK_SECRET && authHeader !== `Bearer ${WEBHOOK_SECRET}`) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()

    // Handle different webhook formats
    const {
      query,
      queryType,
      attackerId,
      attackerUsername,
      source,
    } = body

    if (!query || !queryType) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    // Detect and alert
    const alert = await detectOSINTQuery(
      query,
      queryType as 'phone' | 'username' | 'email',
      attackerId,
      attackerUsername,
      source
    )

    if (alert) {
      return NextResponse.json({
        success: true,
        alerted: true,
        userId: alert.userId,
      })
    }

    return NextResponse.json({
      success: true,
      alerted: false,
      message: 'Query not matching any protected user',
    })
  } catch (error) {
    console.error('OSINT intercept error:', error)
    return NextResponse.json({ error: 'Internal error' }, { status: 500 })
  }
}

// Also handle GET for simple ping/status
export async function GET() {
  return NextResponse.json({
    status: 'active',
    service: 'vacwerTOR OSINT Interceptor',
    timestamp: new Date().toISOString(),
  })
}
