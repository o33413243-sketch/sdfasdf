import { createClient } from "@/lib/supabase/server"
import { checkAllOsintSources } from "@/lib/osint-monitor"
import { NextResponse } from "next/server"

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN

async function sendTelegramMessage(chatId: number, text: string, replyMarkup?: object) {
  const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`
  await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: chatId,
      text,
      parse_mode: "HTML",
      reply_markup: replyMarkup,
    }),
  })
}

export async function GET(request: Request) {
  // Verify cron secret for security (optional - skip if not set)
  const cronSecret = process.env.CRON_SECRET
  if (cronSecret) {
    const authHeader = request.headers.get("authorization")
    if (authHeader !== `Bearer ${cronSecret}`) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }
  }

  const supabase = await createClient()

  // Get all users with notifications enabled
  const { data: users, error } = await supabase
    .from("tg_users")
    .select("*")
    .eq("notifications_enabled", true)

  if (error || !users) {
    return NextResponse.json({ error: "Failed to fetch users" }, { status: 500 })
  }

  let threatsFound = 0

  for (const user of users) {
    const usernames = user.monitored_usernames || []
    const phones = user.monitored_phones || []
    const emails = user.monitored_emails || []

    // Skip users with no data to monitor
    if (usernames.length === 0 && phones.length === 0 && emails.length === 0) {
      continue
    }

    // Check OSINT sources
    const threats = await checkAllOsintSources(usernames, phones, emails)

    for (const threat of threats) {
      // Check if this threat was already detected (within last 24 hours)
      const { data: existingThreat } = await supabase
        .from("threats")
        .select("id")
        .eq("telegram_id", user.telegram_id)
        .eq("service_name", threat.service)
        .eq("data_found", threat.dataFound)
        .gte("detected_at", new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString())
        .single()

      if (!existingThreat) {
        // Save new threat
        await supabase.from("threats").insert({
          telegram_id: user.telegram_id,
          service_name: threat.service,
          threat_level: threat.level,
          data_found: threat.dataFound,
          details: threat.details,
        })

        threatsFound++

        // Send alert to user
        const levelEmoji = threat.level === "critical" ? "🚨" : threat.level === "high" ? "⚠️" : "📢"
        const alertText = `${levelEmoji} <b>ОБНАРУЖЕНА УГРОЗА</b>

<b>Сервис:</b> ${threat.service}
<b>Уровень:</b> ${threat.level.toUpperCase()}
<b>Найдено:</b> <code>${threat.dataFound}</code>

<b>Подробности:</b>
${threat.details}

<i>Рекомендуем проверить и принять меры по защите ваших данных.</i>`

        await sendTelegramMessage(user.telegram_id, alertText, {
          inline_keyboard: [
            [{ text: "📊 Все угрозы", callback_data: "threats_history" }],
            [{ text: "🛡 Рекомендации", callback_data: "protection_tips" }],
          ],
        })
      }
    }
  }

  return NextResponse.json({
    success: true,
    usersChecked: users.length,
    threatsFound,
    timestamp: new Date().toISOString(),
  })
}
