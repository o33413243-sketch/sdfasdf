import { type NextRequest, NextResponse } from "next/server"

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN!
const BLACK_HOLE_IMAGE = "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=800&q=80"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { chatId, message, inlineKeyboard, withPhoto } = body

    if (!TELEGRAM_BOT_TOKEN) {
      return NextResponse.json({ error: "Bot token not configured" }, { status: 500 })
    }

    // Send with photo if requested
    if (withPhoto) {
      const photoPayload: {
        chat_id: number
        photo: string
        caption: string
        parse_mode: string
        reply_markup?: {
          inline_keyboard: Array<Array<{ text: string; web_app?: { url: string }; callback_data?: string }>>
        }
      } = {
        chat_id: chatId,
        photo: BLACK_HOLE_IMAGE,
        caption: message,
        parse_mode: "HTML",
      }

      if (inlineKeyboard) {
        photoPayload.reply_markup = {
          inline_keyboard: inlineKeyboard,
        }
      }

      const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendPhoto`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(photoPayload),
      })

      const data = await response.json()

      if (!data.ok) {
        console.error("Telegram API error:", data)
        return NextResponse.json({ error: data.description }, { status: 400 })
      }

      return NextResponse.json({ success: true, result: data.result })
    }

    // Send text message
    const payload: {
      chat_id: number
      text: string
      parse_mode: string
      reply_markup?: {
        inline_keyboard: Array<Array<{ text: string; web_app?: { url: string }; callback_data?: string }>>
      }
    } = {
      chat_id: chatId,
      text: message,
      parse_mode: "HTML",
    }

    if (inlineKeyboard) {
      payload.reply_markup = {
        inline_keyboard: inlineKeyboard,
      }
    }

    const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    })

    const data = await response.json()

    if (!data.ok) {
      console.error("Telegram API error:", data)
      return NextResponse.json({ error: data.description }, { status: 400 })
    }

    return NextResponse.json({ success: true, result: data.result })
  } catch (error) {
    console.error("Send message error:", error)
    return NextResponse.json({ error: "Failed to send message" }, { status: 500 })
  }
}
