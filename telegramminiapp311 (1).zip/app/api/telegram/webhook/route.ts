import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"
import { OSINT_SERVICES, SOCIAL_NETWORKS, getRiskEmoji, getRiskText } from "@/lib/osint-monitor"
import { detectOSINTQuery, checkUserBreaches, createCanaryToken, OSINT_TELEGRAM_BOTS } from "@/lib/osint-detector"

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || ""
const ADMIN_ID = 7251987829 // Admin user ID

// Supabase client
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

interface TelegramUpdate {
  update_id: number
  message?: {
    message_id: number
    from: {
      id: number
      is_bot: boolean
      first_name: string
      last_name?: string
      username?: string
    }
    chat: { id: number; type: string }
    date: number
    text?: string
    forward_from?: {
      id: number
      is_bot: boolean
      first_name: string
      username?: string
    }
    forward_from_chat?: {
      id: number
      type: string
      title?: string
      username?: string
    }
    reply_to_message?: {
      from?: { id: number; username?: string }
      text?: string
    }
  }
  callback_query?: {
    id: string
    from: { id: number; first_name: string; username?: string }
    message?: { message_id: number; chat: { id: number } }
    data?: string
  }
}

// User state for multi-step interactions
const userStates = new Map<number, { action: string; step: number; data?: Record<string, unknown> }>()

// Telegram API helpers
async function sendMessage(chatId: number, text: string, keyboard?: object) {
  const body: Record<string, unknown> = { chat_id: chatId, text, parse_mode: "HTML" }
  if (keyboard) body.reply_markup = keyboard
  
  await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  })
}

async function editMessage(chatId: number, messageId: number, text: string, keyboard?: object) {
  const body: Record<string, unknown> = { chat_id: chatId, message_id: messageId, text, parse_mode: "HTML" }
  if (keyboard) body.reply_markup = keyboard
  
  await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/editMessageText`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  })
}

async function answerCallback(callbackId: string, text?: string, showAlert = false) {
  await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/answerCallbackQuery`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ callback_query_id: callbackId, text, show_alert: showAlert }),
  })
}

async function deleteMessage(chatId: number, messageId: number) {
  await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/deleteMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, message_id: messageId }),
  })
}

// Get or create user in database
async function getOrCreateUser(userId: number, firstName: string, lastName?: string, username?: string) {
  const { data: existingUser } = await supabase
    .from('tg_users')
    .select('*')
    .eq('id', userId)
    .single()
  
  if (existingUser) {
    // Update user info
    await supabase.from('tg_users').update({
      first_name: firstName,
      last_name: lastName || null,
      username: username || null,
      updated_at: new Date().toISOString()
    }).eq('id', userId)
    return existingUser
  }
  
  // Create new user
  const { data: newUser } = await supabase.from('tg_users').insert({
    id: userId,
    first_name: firstName,
    last_name: lastName || null,
    username: username || null,
    protection_enabled: false,
    is_premium: false,
    protection_stats: { threats_blocked: 0, scans_detected: 0, last_threat: null },
    monitored_usernames: username ? [username] : [],
    monitored_phones: [],
    monitored_emails: [],
    notifications_enabled: true
  }).select().single()
  
  return newUser
}

// Get user's threat history
async function getUserThreats(userId: number, limit = 10) {
  const { data } = await supabase
    .from('threats')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(limit)
  
  return data || []
}

// Save threat to database
async function saveThreat(userId: number, threat: {
  type: string
  source: string
  sourceUrl?: string
  ipAddress?: string
  region?: string
  queryData?: string
}) {
  await supabase.from('threats').insert({
    user_id: userId,
    threat_type: threat.type,
    source: threat.source,
    source_url: threat.sourceUrl,
    ip_address: threat.ipAddress,
    region: threat.region,
    query_data: threat.queryData,
    blocked: true
  })
  
  // Update user stats
  const { data: user } = await supabase.from('tg_users').select('protection_stats').eq('id', userId).single()
  if (user) {
    const stats = user.protection_stats || { threats_blocked: 0, scans_detected: 0 }
    await supabase.from('tg_users').update({
      protection_stats: {
        ...stats,
        threats_blocked: (stats.threats_blocked || 0) + 1,
        scans_detected: (stats.scans_detected || 0) + 1,
        last_threat: new Date().toISOString()
      }
    }).eq('id', userId)
  }
}

// Check username on social networks
async function checkUsername(username: string): Promise<{ found: string[]; checked: number }> {
  const found: string[] = []
  let checked = 0
  
  for (const network of SOCIAL_NETWORKS.slice(0, 8)) { // Check first 8 to avoid timeout
    try {
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 3000)
      
      const response = await fetch(network.url(username), {
        method: 'HEAD',
        signal: controller.signal,
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
      })
      
      clearTimeout(timeoutId)
      checked++
      
      if (response.ok || response.status === 301 || response.status === 302) {
        found.push(network.name)
      }
    } catch {
      checked++
    }
  }
  
  return { found, checked }
}

function getAppUrl(request: Request): string {
  const host = request.headers.get("x-forwarded-host") || request.headers.get("host")
  const proto = request.headers.get("x-forwarded-proto") || "https"
  return host ? `${proto}://${host}` : process.env.NEXT_PUBLIC_APP_URL || "https://vacwertor.vercel.app"
}

function isAdmin(userId: number): boolean {
  return userId === ADMIN_ID
}

// Keyboards
function getMainKeyboard(appUrl: string, isAdminUser: boolean) {
  const keyboard = [
    [{ text: "🛡 Открыть vacwerTOR", web_app: { url: appUrl } }],
    [
      { text: "🔍 Проверить username", callback_data: "check_username" },
      { text: "📊 Статистика", callback_data: "stats" }
    ],
    [
      { text: "🔔 Оповещения", callback_data: "notifications" },
      { text: "⚙️ Настройки", callback_data: "settings" }
    ],
    [
      { text: "📜 История угроз", callback_data: "threat_history" },
      { text: "ℹ️ О боте", callback_data: "about" }
    ]
  ]
  
  if (isAdminUser) {
    keyboard.push([{ text: "🔐 Админ панель", callback_data: "admin" }])
  }
  
  return { inline_keyboard: keyboard }
}

function getBackKeyboard(callback = "menu") {
  return { inline_keyboard: [[{ text: "◀️ Назад", callback_data: callback }]] }
}

// Message templates
function getWelcomeMessage(firstName: string) {
  return `
<b>🌌 vacwerTOR</b>
<i>Защита от цифровых угроз</i>

━━━━━━━━━━━━━━━━━━━━

Привет, <b>${firstName}</b>!

Я защищаю тебя от:

<b>🔍 OSINT-ботов</b>
GetContact, Глаз Бога, TrueCaller, 
Sherlock, Maigret и других

<b>📱 Пробива номера</b>
Блокирую запросы к твоим данным

<b>👁 Сканирования профиля</b>
Уведомляю о попытках поиска

━━━━━━━━━━━━━━━━━━━━

<b>Выбери действие:</b>`
}

function getOsintListMessage() {
  const services = OSINT_SERVICES.slice(0, 15).map(s => 
    `${getRiskEmoji(s.riskLevel)} <b>${s.name}</b> — ${getRiskText(s.riskLevel)}`
  ).join('\n')
  
  return `
<b>🛡 Защита от OSINT-сервисов</b>

<b>Мониторинг угроз:</b>

${services}

<i>...и ещё ${OSINT_SERVICES.length - 15} сервисов</i>

━━━━━━━━━━━━━━━━━━━━

vacwerTOR блокирует запросы от этих 
сервисов и уведомляет тебя о попытках 
сканирования твоего профиля.`
}

export async function POST(request: Request) {
  try {
    const update: TelegramUpdate = await request.json()
    const appUrl = getAppUrl(request)
    
    // Handle text messages
    if (update.message?.text) {
      const chatId = update.message.chat.id
      const userId = update.message.from.id
      const firstName = update.message.from.first_name
      const lastName = update.message.from.last_name
      const username = update.message.from.username
      const text = update.message.text
      
      // Get or create user
      await getOrCreateUser(userId, firstName, lastName, username)
      
      // Check user state for multi-step actions
      const state = userStates.get(userId)
      
      if (state?.action === 'add_username' && !text.startsWith('/')) {
        const newUsername = text.replace('@', '').trim()
        await supabase.rpc('array_append_unique', { 
          table_name: 'tg_users', 
          column_name: 'monitored_usernames',
          row_id: userId,
          new_value: newUsername 
        }).catch(() => {
          // Fallback: get current and update
          supabase.from('tg_users').select('monitored_usernames').eq('id', userId).single()
            .then(({ data }) => {
              const current = data?.monitored_usernames || []
              if (!current.includes(newUsername)) {
                supabase.from('tg_users').update({ monitored_usernames: [...current, newUsername] }).eq('id', userId)
              }
            })
        })
        
        userStates.delete(userId)
        await sendMessage(chatId, `✅ Username <b>@${newUsername}</b> добавлен в мониторинг!`, getBackKeyboard('settings'))
        return NextResponse.json({ ok: true })
      }
      
      if (state?.action === 'add_phone' && !text.startsWith('/')) {
        const phone = text.replace(/[^\d+]/g, '')
        await supabase.from('tg_users').select('monitored_phones').eq('id', userId).single()
          .then(({ data }) => {
            const current = data?.monitored_phones || []
            if (!current.includes(phone)) {
              supabase.from('tg_users').update({ monitored_phones: [...current, phone] }).eq('id', userId)
            }
          })
        
        userStates.delete(userId)
        await sendMessage(chatId, `✅ Телефон <b>${phone}</b> добавлен в мониторинг!`, getBackKeyboard('settings'))
        return NextResponse.json({ ok: true })
      }
      
      if (state?.action === 'add_email' && !text.startsWith('/')) {
        const email = text.trim().toLowerCase()
        await supabase.from('tg_users').select('monitored_emails').eq('id', userId).single()
          .then(({ data }) => {
            const current = data?.monitored_emails || []
            if (!current.includes(email)) {
              supabase.from('tg_users').update({ monitored_emails: [...current, email] }).eq('id', userId)
            }
          })
        
        userStates.delete(userId)
        await sendMessage(chatId, `✅ Email <b>${email}</b> добавлен в мониторинг!`, getBackKeyboard('settings'))
        return NextResponse.json({ ok: true })
      }
      
      // Admin broadcast handler
      if (state?.action === 'admin_broadcast' && !text.startsWith('/') && isAdmin(userId)) {
        userStates.delete(userId)
        
        await sendMessage(chatId, '📤 Начинаю рассылку...')
        
        const { data: allUsers } = await supabase.from('tg_users').select('id')
        let sent = 0
        let failed = 0
        
        for (const u of allUsers || []) {
          try {
            await sendMessage(u.id, text)
            sent++
            // Small delay to avoid rate limits
            await new Promise(r => setTimeout(r, 50))
          } catch {
            failed++
          }
        }
        
        await sendMessage(chatId, `
✅ <b>Рассылка завершена!</b>

📤 Отправлено: <b>${sent}</b>
❌ Ошибок: <b>${failed}</b>`, getBackKeyboard('admin'))
        return NextResponse.json({ ok: true })
      }
      
      if (state?.action === 'check_username' && !text.startsWith('/')) {
        const checkingUsername = text.replace('@', '').trim()
        userStates.delete(userId)
        
        await sendMessage(chatId, `🔍 Проверяю <b>@${checkingUsername}</b>...`)
        
        const { found, checked } = await checkUsername(checkingUsername)
        
        const resultText = found.length > 0 
          ? `
<b>🔍 Результаты проверки @${checkingUsername}</b>

Проверено платформ: <b>${checked}</b>
Найдено аккаунтов: <b>${found.length}</b>

<b>Найден на:</b>
${found.map(f => `• ${f}`).join('\n')}

⚠️ <b>Внимание!</b> Эти данные видны 
OSINT-инструментам. Рекомендуем 
активировать защиту.`
          : `
<b>🔍 Результаты проверки @${checkingUsername}</b>

Проверено платформ: <b>${checked}</b>
Найдено аккаунтов: <b>0</b>

✅ Username не найден на проверенных 
платформах или профили приватные.`
        
        await sendMessage(chatId, resultText, getBackKeyboard('menu'))
        return NextResponse.json({ ok: true })
      }
      
      // Detect forwarded messages from OSINT bots
      const forwardedFrom = update.message.forward_from
      const forwardedFromChat = update.message.forward_from_chat
      
      if (forwardedFrom?.is_bot || forwardedFromChat) {
        const botUsername = forwardedFrom?.username || forwardedFromChat?.username || ''
        const isOsintBot = OSINT_TELEGRAM_BOTS.some(
          bot => bot.username === botUsername || bot.aliases.includes(botUsername)
        )
        
        if (isOsintBot) {
          // Extract phone/username/email from forwarded message
          const phoneMatch = text.match(/\+?\d{10,15}/)
          const usernameMatch = text.match(/@(\w{3,32})/)
          const emailMatch = text.match(/[\w.-]+@[\w.-]+\.\w+/)
          
          const botName = OSINT_TELEGRAM_BOTS.find(
            b => b.username === botUsername || b.aliases.includes(botUsername)
          )?.name || 'OSINT Bot'
          
          if (phoneMatch) {
            await detectOSINTQuery(phoneMatch[0], 'phone', userId, username, botName)
          }
          if (usernameMatch) {
            await detectOSINTQuery(usernameMatch[1], 'username', userId, username, botName)
          }
          if (emailMatch) {
            await detectOSINTQuery(emailMatch[0], 'email', userId, username, botName)
          }
          
          await sendMessage(chatId, `
🔍 <b>Обнаружено использование OSINT-бота!</b>

Вы переслали сообщение из <b>${botName}</b>.

Если кто-то пробивал ваши данные, 
мы уведомим защищаемого пользователя.

🛡 <i>vacwerTOR следит за безопасностью</i>
`, getBackKeyboard('menu'))
          return NextResponse.json({ ok: true })
        }
      }

      // Commands
      if (text === '/start') {
        await sendMessage(chatId, getWelcomeMessage(firstName), getMainKeyboard(appUrl, isAdmin(userId)))
      } else if (text === '/help') {
        await sendMessage(chatId, `
<b>❓ Помощь vacwerTOR</b>

<b>Команды:</b>
/start — Главное меню
/help — Эта справка
/status — Статус защиты
/osint — Список OSINT-сервисов

<b>Как это работает:</b>
1. Добавь свои данные для мониторинга
2. Включи уведомления
3. Получай алерты при попытках пробива

<b>Поддержка:</b> @vacwertor_support`, getBackKeyboard('menu'))
      } else if (text === '/status') {
        const { data: user } = await supabase.from('tg_users').select('*').eq('id', userId).single()
        const stats = user?.protection_stats || {}
        
        await sendMessage(chatId, `
<b>📊 Статус защиты</b>

<b>Защита:</b> ${user?.protection_enabled ? '🟢 Активна' : '🔴 Выключена'}
<b>Уведомления:</b> ${user?.notifications_enabled ? '🔔 Включены' : '🔕 Выключены'}

<b>Статистика:</b>
• Угроз заблокировано: <b>${stats.threats_blocked || 0}</b>
• Сканирований обнаружено: <b>${stats.scans_detected || 0}</b>

<b>Мониторинг:</b>
• Usernames: <b>${user?.monitored_usernames?.length || 0}</b>
• Телефоны: <b>${user?.monitored_phones?.length || 0}</b>
• Email: <b>${user?.monitored_emails?.length || 0}</b>`, getBackKeyboard('menu'))
      } else if (text === '/osint') {
        await sendMessage(chatId, getOsintListMessage(), getBackKeyboard('menu'))
      } else if (text === '/canary') {
        // Create canary token for user
        const canaryUrl = await createCanaryToken(userId, 'general')
        await sendMessage(chatId, `
🎣 <b>Канареечный токен создан!</b>

Этот URL будет отслеживаться:
<code>${canaryUrl}</code>

<b>Как использовать:</b>
1. Добавь эту ссылку в свой профиль
2. Или используй как контактный email
3. Когда кто-то перейдёт по ней — 
   ты получишь уведомление!

⚠️ <i>Не переходи сам, чтобы не 
сработало ложное оповещение</i>
`, getBackKeyboard('menu'))
      } else if (text === '/breach') {
        // Check for data breaches
        await sendMessage(chatId, '🔍 Проверяю утечки данных...')
        const result = await checkUserBreaches(userId)
        
        if (result.hasBreaches) {
          await sendMessage(chatId, `
⚠️ <b>Обнаружены утечки данных!</b>

<b>Новые утечки:</b>
${result.newBreaches.map(b => `• ${b}`).join('\n')}

🛡 Рекомендуем сменить пароли 
на затронутых сервисах.
`, getBackKeyboard('menu'))
        } else {
          await sendMessage(chatId, `
✅ <b>Новых утечек не обнаружено!</b>

Ваши email адреса не найдены 
в новых базах утечек.

<i>Проверка выполнена через HIBP</i>
`, getBackKeyboard('menu'))
        }
      } else if (text === '/report') {
        // Report someone trying to look you up
        userStates.set(userId, { action: 'report_osint', step: 1 })
        await sendMessage(chatId, `
🚨 <b>Сообщить о пробиве</b>

Если кто-то пытался вас пробить, 
отправьте информацию:

1. Username того, кто пробивал
2. Или перешлите сообщение из OSINT-бота

<i>Мы уведомим защищаемых пользователей</i>
`, getBackKeyboard('menu'))
      }
    }
    
    // Handle callback queries
    if (update.callback_query) {
      const callback = update.callback_query
      const chatId = callback.message?.chat.id
      const messageId = callback.message?.message_id
      const userId = callback.from.id
      const data = callback.data
      
      await answerCallback(callback.id)
      
      if (!chatId || !messageId) return NextResponse.json({ ok: true })
      
      const appUrlForCallback = getAppUrl(request)
      
      switch (data) {
        case 'menu':
          await editMessage(chatId, messageId, getWelcomeMessage(callback.from.first_name), getMainKeyboard(appUrlForCallback, isAdmin(userId)))
          break
          
        case 'check_username':
          userStates.set(userId, { action: 'check_username', step: 1 })
          await editMessage(chatId, messageId, `
<b>🔍 Проверка username</b>

Отправь username для проверки 
(с @ или без):

<i>Например: @durov или durov</i>`, getBackKeyboard('menu'))
          break
          
        case 'stats':
          const { data: userData } = await supabase.from('tg_users').select('*').eq('id', userId).single()
          const userStats = userData?.protection_stats || {}
          
          await editMessage(chatId, messageId, `
<b>📊 Твоя статистика</b>

━━━━━━━━━━━━━━━━━━━━

<b>Защита:</b> ${userData?.protection_enabled ? '🟢 Активна' : '🔴 Выключена'}

<b>За всё время:</b>
🛡 Угроз заблокировано: <b>${userStats.threats_blocked || 0}</b>
🔍 Сканирований: <b>${userStats.scans_detected || 0}</b>

<b>Мониторится:</b>
👤 Usernames: <b>${userData?.monitored_usernames?.length || 0}</b>
📱 Телефоны: <b>${userData?.monitored_phones?.length || 0}</b>
📧 Email: <b>${userData?.monitored_emails?.length || 0}</b>

━━━━━━━━━━━━━━━━━━━━

${userStats.last_threat ? `<i>Последняя угроза: ${new Date(userStats.last_threat).toLocaleString('ru-RU')}</i>` : '<i>Угроз пока не было</i>'}`, {
            inline_keyboard: [
              [{ text: "📜 История угроз", callback_data: "threat_history" }],
              [{ text: "◀️ Назад", callback_data: "menu" }]
            ]
          })
          break
          
        case 'notifications':
          const { data: notifUser } = await supabase.from('tg_users').select('notifications_enabled').eq('id', userId).single()
          const notifEnabled = notifUser?.notifications_enabled ?? true
          
          await editMessage(chatId, messageId, `
<b>🔔 Настройки оповещений</b>

Статус: ${notifEnabled ? '🔔 Включены' : '🔕 Выключены'}

Когда включены, ты получаешь 
уведомления о:

• 🚨 Обнаруженных угрозах
• 🔍 Попытках сканирования
• 📊 Еженедельных отчётах`, {
            inline_keyboard: [
              [{ text: notifEnabled ? "🔕 Выключить" : "🔔 Включить", callback_data: "toggle_notif" }],
              [{ text: "◀️ Назад", callback_data: "menu" }]
            ]
          })
          break
          
        case 'toggle_notif':
          const { data: currentUser } = await supabase.from('tg_users').select('notifications_enabled').eq('id', userId).single()
          const newState = !(currentUser?.notifications_enabled ?? true)
          await supabase.from('tg_users').update({ notifications_enabled: newState }).eq('id', userId)
          
          await answerCallback(callback.id, newState ? '🔔 Уведомления включены' : '🔕 Уведомления выключены', true)
          
          // Refresh the view
          await editMessage(chatId, messageId, `
<b>🔔 Настройки оповещений</b>

Статус: ${newState ? '🔔 Включены' : '🔕 Выключены'}

Когда включены, ты получаешь 
уведомления о:

• 🚨 Обнаруженных угрозах
• 🔍 Попытках сканирования
• 📊 Еженедельных отчётах`, {
            inline_keyboard: [
              [{ text: newState ? "🔕 Выключить" : "🔔 Включить", callback_data: "toggle_notif" }],
              [{ text: "◀️ Назад", callback_data: "menu" }]
            ]
          })
          break
          
        case 'settings':
          const { data: settingsUser } = await supabase.from('tg_users').select('*').eq('id', userId).single()
          
          const usernames = settingsUser?.monitored_usernames || []
          const phones = settingsUser?.monitored_phones || []
          const emails = settingsUser?.monitored_emails || []
          
          await editMessage(chatId, messageId, `
<b>⚙️ Настройки мониторинга</b>

<b>Твои данные для защиты:</b>

<b>👤 Usernames (${usernames.length}):</b>
${usernames.length ? usernames.map((u: string) => `• @${u}`).join('\n') : '<i>Не добавлены</i>'}

<b>📱 Телефоны (${phones.length}):</b>
${phones.length ? phones.map((p: string) => `• ${p}`).join('\n') : '<i>Не добавлены</i>'}

<b>📧 Email (${emails.length}):</b>
${emails.length ? emails.map((e: string) => `• ${e}`).join('\n') : '<i>Не добавлены</i>'}

━━━━━━━━━━━━━━━━━━━━

Добавь данные для мониторинга:`, {
            inline_keyboard: [
              [
                { text: "➕ Username", callback_data: "add_username" },
                { text: "➕ Телефон", callback_data: "add_phone" }
              ],
              [
                { text: "➕ Email", callback_data: "add_email" },
                { text: "🗑 Очистить", callback_data: "clear_data" }
              ],
              [{ text: "◀️ Назад", callback_data: "menu" }]
            ]
          })
          break
          
        case 'add_username':
          userStates.set(userId, { action: 'add_username', step: 1 })
          await editMessage(chatId, messageId, `
<b>➕ Добавить username</b>

Отправь username который хочешь 
защитить (с @ или без):

<i>Например: @myusername</i>`, getBackKeyboard('settings'))
          break
          
        case 'add_phone':
          userStates.set(userId, { action: 'add_phone', step: 1 })
          await editMessage(chatId, messageId, `
<b>➕ Добавить телефон</b>

Отправь номер телефона:

<i>Например: +79001234567</i>`, getBackKeyboard('settings'))
          break
          
        case 'add_email':
          userStates.set(userId, { action: 'add_email', step: 1 })
          await editMessage(chatId, messageId, `
<b>➕ Добавить email</b>

Отправь email адрес:

<i>Например: myemail@example.com</i>`, getBackKeyboard('settings'))
          break
          
        case 'clear_data':
          await editMessage(chatId, messageId, `
<b>🗑 Очистить данные</b>

Выбери что удалить:`, {
            inline_keyboard: [
              [{ text: "🗑 Все usernames", callback_data: "clear_usernames" }],
              [{ text: "🗑 Все телефоны", callback_data: "clear_phones" }],
              [{ text: "🗑 Все email", callback_data: "clear_emails" }],
              [{ text: "⚠️ Удалить ВСЁ", callback_data: "clear_all" }],
              [{ text: "◀️ Назад", callback_data: "settings" }]
            ]
          })
          break
          
        case 'clear_usernames':
          await supabase.from('tg_users').update({ monitored_usernames: [] }).eq('id', userId)
          await answerCallback(callback.id, '✅ Usernames удалены', true)
          break
          
        case 'clear_phones':
          await supabase.from('tg_users').update({ monitored_phones: [] }).eq('id', userId)
          await answerCallback(callback.id, '✅ Телефоны удалены', true)
          break
          
        case 'clear_emails':
          await supabase.from('tg_users').update({ monitored_emails: [] }).eq('id', userId)
          await answerCallback(callback.id, '✅ Email удалены', true)
          break
          
        case 'clear_all':
          await supabase.from('tg_users').update({ 
            monitored_usernames: [], 
            monitored_phones: [], 
            monitored_emails: [] 
          }).eq('id', userId)
          await answerCallback(callback.id, '✅ Все данные удалены', true)
          break
          
        case 'threat_history':
          const threats = await getUserThreats(userId, 5)
          
          const threatText = threats.length ? threats.map(t => 
            `${getRiskEmoji(t.threat_type === 'critical' ? 'critical' : 'high')} <b>${t.source}</b>
   ${t.threat_type} | ${new Date(t.created_at).toLocaleString('ru-RU')}`
          ).join('\n\n') : '<i>История угроз пуста</i>'
          
          await editMessage(chatId, messageId, `
<b>📜 История угроз</b>

${threatText}

━━━━━━━━━━━━━━━━━━━━

<i>Показаны последние 5 угроз</i>`, {
            inline_keyboard: [
              [{ text: "🔄 Обновить", callback_data: "threat_history" }],
              [{ text: "◀️ Назад", callback_data: "menu" }]
            ]
          })
          break
          
        case 'about':
          await editMessage(chatId, messageId, `
<b>ℹ️ О vacwerTOR</b>

vacwerTOR — сервис защиты от 
OSINT-инструментов и пробива.

<b>🛡 Возможности:</b>
• Мониторинг ${OSINT_SERVICES.length}+ OSINT-сервисов
• Проверка ${SOCIAL_NETWORKS.length}+ соцсетей
• Уведомления в реальном времени
• История угроз

<b>📱 Версия:</b> 2.0.0
<b>👨‍💻 Команда:</b> vacwerTOR Team

<i>Твоя приватность — наш приоритет.</i>`, {
            inline_keyboard: [
              [{ text: "📋 Список OSINT", callback_data: "osint_list" }],
              [{ text: "◀️ Назад", callback_data: "menu" }]
            ]
          })
          break
          
        case 'osint_list':
          await editMessage(chatId, messageId, getOsintListMessage(), getBackKeyboard('about'))
          break
          
        case 'admin':
          if (!isAdmin(userId)) {
            await answerCallback(callback.id, '🚫 Нет доступа', true)
            break
          }
          
          const { count: totalUsers } = await supabase.from('tg_users').select('*', { count: 'exact', head: true })
          const { count: activeProtection } = await supabase.from('tg_users').select('*', { count: 'exact', head: true }).eq('protection_enabled', true)
          const { count: totalThreats } = await supabase.from('threats').select('*', { count: 'exact', head: true })
          const { count: premiumUsers } = await supabase.from('tg_users').select('*', { count: 'exact', head: true }).eq('is_premium', true)
          
          await editMessage(chatId, messageId, `
<b>🔐 Админ панель vacwerTOR</b>

━━━━━━━━━━━━━━━━━━━━

<b>📊 Статистика:</b>
👥 Пользователей: <b>${totalUsers || 0}</b>
🛡 С защитой: <b>${activeProtection || 0}</b>
⭐️ Premium: <b>${premiumUsers || 0}</b>
🚨 Угроз: <b>${totalThreats || 0}</b>

<b>⏰ Сервер:</b>
${new Date().toLocaleString('ru-RU')}

━━━━━━━━━━━━━━━━━━━━`, {
            inline_keyboard: [
              [{ text: "📢 Рассылка", callback_data: "admin_broadcast" }],
              [{ text: "👥 Пользователи", callback_data: "admin_users" }],
              [{ text: "🔄 Обновить", callback_data: "admin" }],
              [{ text: "◀️ Назад", callback_data: "menu" }]
            ]
          })
          break
          
        case 'admin_broadcast':
          if (!isAdmin(userId)) {
            await answerCallback(callback.id, '🚫 Нет доступа', true)
            break
          }
          userStates.set(userId, { action: 'admin_broadcast', step: 1 })
          await editMessage(chatId, messageId, `
<b>📢 Рассылка сообщения</b>

Отправь текст для рассылки всем 
пользователям бота.

<i>Поддерживается HTML-разметка</i>`, getBackKeyboard('admin'))
          break
          
        case 'admin_users':
          if (!isAdmin(userId)) {
            await answerCallback(callback.id, '🚫 Нет доступа', true)
            break
          }
          
          const { data: recentUsers } = await supabase
            .from('tg_users')
            .select('id, first_name, username, protection_enabled, created_at')
            .order('created_at', { ascending: false })
            .limit(10)
          
          const usersListText = recentUsers?.map((u, i) => 
            `${i + 1}. ${u.first_name}${u.username ? ` (@${u.username})` : ''} ${u.protection_enabled ? '🛡' : ''}`
          ).join('\n') || 'Нет пользователей'
          
          await editMessage(chatId, messageId, `
<b>👥 Последние пользователи</b>

${usersListText}

<i>Показаны последние 10</i>`, {
            inline_keyboard: [
              [{ text: "🔄 Обновить", callback_data: "admin_users" }],
              [{ text: "◀️ Назад", callback_data: "admin" }]
            ]
          })
          break
      }
    }
    
    return NextResponse.json({ ok: true })
  } catch (error) {
    console.error("Webhook error:", error)
    return NextResponse.json({ error: "Failed" }, { status: 500 })
  }
}

export async function GET() {
  return NextResponse.json({ status: "vacwerTOR webhook active", version: "2.0.0" })
}
