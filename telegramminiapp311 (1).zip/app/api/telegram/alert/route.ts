import { type NextRequest, NextResponse } from "next/server"

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN!

// OSINT threat data
const OSINT_BOTS = [
  "GetContact", "NumBuster", "TrueCaller", "EyeOfGod", 
  "QuickOSINT", "Insight", "Глаз Бога", "AVinfo",
  "SmartSearchBot", "LeakCheck", "PhoneRadar"
]

const THREAT_TYPES = [
  "сканирование профиля",
  "запрос номера телефона", 
  "поиск в базах данных",
  "проверка социальных сетей",
  "анализ контактов",
  "геолокационный запрос"
]

function getRandomElement<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)]
}

function getRandomIP(): string {
  return `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`
}

async function sendTelegramMessage(chatId: number, text: string, replyMarkup?: object) {
  const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`

  const body: Record<string, unknown> = {
    chat_id: chatId,
    text,
    parse_mode: "HTML",
  }

  if (replyMarkup) {
    body.reply_markup = replyMarkup
  }

  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  })

  return response.json()
}

// Send threat alert to user
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { chatId, customThreat } = body

    if (!chatId) {
      return NextResponse.json({ error: "chatId is required" }, { status: 400 })
    }

    const now = new Date()
    const timeStr = now.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit", second: "2-digit" })
    const dateStr = now.toLocaleDateString("ru-RU")

    // Generate threat info
    const threatType = customThreat?.type || getRandomElement(THREAT_TYPES)
    const threatSource = customThreat?.source || getRandomElement(OSINT_BOTS)
    const threatIP = customThreat?.ip || getRandomIP()
    const threatRegion = customThreat?.region || getRandomElement(["Россия", "Украина", "Беларусь", "Казахстан", "Узбекистан"])

    const alertText = `
🚨 <b>ВНИМАНИЕ! Обнаружена угроза!</b>

━━━━━━━━━━━━━━━━━━━━

🔍 <b>Тип угрозы:</b> ${threatType}
🤖 <b>Источник:</b> ${threatSource}
🌐 <b>IP-адрес:</b> <code>${threatIP}</code>
📍 <b>Регион:</b> ${threatRegion}
🕐 <b>Время:</b> ${timeStr}
📅 <b>Дата:</b> ${dateStr}

━━━━━━━━━━━━━━━━━━━━

🛡 <b>vacwerTOR защитил вас!</b>
Запрос был <b>заблокирован</b>.

📊 <b>Статус:</b> 🟢 Угроза нейтрализована

<i>💡 Совет: Для расширенной защиты 
активируйте Стандартный тариф</i>
`

    const keyboard = {
      inline_keyboard: [
        [{ text: "📊 Подробнее", callback_data: "threat_details" }],
        [{ text: "🛡 Усилить защиту", callback_data: "upgrade_protection" }],
        [{ text: "🔕 Отключить уведомления", callback_data: "toggle_notifications" }]
      ]
    }

    const result = await sendTelegramMessage(chatId, alertText, keyboard)

    if (!result.ok) {
      console.error("Telegram API error:", result)
      return NextResponse.json({ error: result.description }, { status: 400 })
    }

    return NextResponse.json({ 
      success: true, 
      message: "Alert sent successfully",
      threat: {
        type: threatType,
        source: threatSource,
        ip: threatIP,
        region: threatRegion,
        time: timeStr,
        date: dateStr
      }
    })

  } catch (error) {
    console.error("Alert send error:", error)
    return NextResponse.json({ error: "Failed to send alert" }, { status: 500 })
  }
}

// Test endpoint - simulate random threat
export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const chatId = searchParams.get("chatId")
  const test = searchParams.get("test")

  if (test === "true" && chatId) {
    // Send test alert
    const response = await POST(new Request(request.url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chatId: parseInt(chatId) })
    }))
    
    return response
  }

  return NextResponse.json({
    status: "vacwerTOR Alert API",
    version: "1.0.0",
    endpoints: {
      POST: "Send threat alert to user",
      GET: "Test alert (add ?chatId=YOUR_ID&test=true)"
    },
    osint_bots: OSINT_BOTS,
    threat_types: THREAT_TYPES
  })
}
