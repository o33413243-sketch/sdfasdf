export const ANIMATIONS = {
  eternalRose: "/animations/eternal-rose.json",
  scaredCat: "/animations/scared-cat.json",
  durovCap: "/animations/durovs-cap.json",
  plushPepe: "/animations/plush-pepe.json",
  signetRing: "/animations/signet-ring.json",
  electricSkull: "/animations/electric-skull.json",
  lowRider: "/animations/low-rider.json",
  perfumeBottle: "/animations/perfume-bottle.json",
  magicPotion: "/animations/magic-potion.json",
}
