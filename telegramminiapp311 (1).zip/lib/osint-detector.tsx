// Real OSINT Detection System
// Detects when someone tries to look up user data in OSINT services

import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

// Telegram Bot API helper
async function sendTelegramMessage(chatId: number, text: string, keyboard?: object) {
  const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN!
  const body: Record<string, unknown> = { chat_id: chatId, text, parse_mode: 'HTML' }
  if (keyboard) body.reply_markup = keyboard

  await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
}

// ============================================
// HONEYPOT TOKEN SYSTEM
// ============================================

// Generate unique honeypot token for user
export function generateHoneypotToken(userId: number, dataType: string): string {
  const timestamp = Date.now().toString(36)
  const random = Math.random().toString(36).substring(2, 8)
  return `vwt_${userId}_${dataType}_${timestamp}_${random}`
}

// Parse honeypot token to get user info
export function parseHoneypotToken(token: string): { userId: number; dataType: string } | null {
  const match = token.match(/^vwt_(\d+)_(\w+)_/)
  if (!match) return null
  return { userId: parseInt(match[1]), dataType: match[2] }
}

// ============================================
// HAVE I BEEN PWNED API
// ============================================

export async function checkHIBP(email: string): Promise<{ breached: boolean; breaches: string[] }> {
  try {
    const response = await fetch(
      `https://haveibeenpwned.com/api/v3/breachedaccount/${encodeURIComponent(email)}?truncateResponse=true`,
      {
        headers: {
          'hibp-api-key': process.env.HIBP_API_KEY || '',
          'user-agent': 'vacwerTOR-OSINT-Protection',
        },
      }
    )

    if (response.status === 404) {
      return { breached: false, breaches: [] }
    }

    if (response.ok) {
      const data = await response.json()
      return {
        breached: true,
        breaches: data.map((b: { Name: string }) => b.Name),
      }
    }

    return { breached: false, breaches: [] }
  } catch {
    return { breached: false, breaches: [] }
  }
}

// ============================================
// LEAKCHECK API (if available)
// ============================================

export async function checkLeakCheck(query: string, type: 'email' | 'phone' | 'username'): Promise<{
  found: boolean
  sources: string[]
}> {
  const apiKey = process.env.LEAKCHECK_API_KEY
  if (!apiKey) return { found: false, sources: [] }

  try {
    const response = await fetch(
      `https://leakcheck.io/api/public?key=${apiKey}&check=${encodeURIComponent(query)}&type=${type}`,
      { headers: { 'User-Agent': 'vacwerTOR-OSINT-Protection' } }
    )

    if (response.ok) {
      const data = await response.json()
      if (data.success && data.found > 0) {
        return {
          found: true,
          sources: data.sources || [],
        }
      }
    }
    return { found: false, sources: [] }
  } catch {
    return { found: false, sources: [] }
  }
}

// ============================================
// TELEGRAM OSINT BOT MONITORING
// ============================================

// Known OSINT Telegram bots that we can detect usage of
// Extensive list of Russian and international OSINT bots
const OSINT_TELEGRAM_BOTS = [
  // Critical Russian OSINT bots
  { name: 'Глаз Бога', username: 'eyeofgodbot', aliases: ['glazboga_bot', 'eyeofgod_bot', 'eyeofgodrobot', 'EyeOfGodBot'] },
  { name: 'Quick OSINT', username: 'quickosintbot', aliases: ['quick_osint_bot', 'QuickOSINTbot'] },
  { name: 'Himera Search', username: 'himaborot', aliases: ['himera_bot', 'HimeraSearchBot'] },
  { name: 'Insight', username: 'insight_osint_bot', aliases: ['insightbot', 'InsightOSINTBot'] },
  { name: 'AVinfo', username: 'AVinfoBot', aliases: ['avinfobot', 'avinfo_bot'] },
  { name: 'Usersbox', username: 'usersbox_bot', aliases: ['UsersboxBot', 'usersboxbot'] },
  
  // Phone lookup bots
  { name: 'GetContact Bot', username: 'getcontact_real_bot', aliases: ['getcontactbot', 'GetContactBot'] },
  { name: 'NumBuster', username: 'numbaborot', aliases: ['numbuster_bot', 'NumBusterBot'] },
  { name: 'TrueCaller Bot', username: 'truecallerbot', aliases: ['TrueCallerBot', 'truecaller_bot'] },
  { name: 'Phone Info', username: 'phone_info_bot', aliases: ['phoneinfobot'] },
  
  // Social media OSINT
  { name: 'TeleSINT', username: 'telosint_bot', aliases: ['telosiint_bot', 'TeleSINTBot'] },
  { name: 'InfoWatch', username: 'infowatchbot', aliases: ['InfoWatchBot', 'infowatch_bot'] },
  { name: 'Sherlock Bot', username: 'sherlockbot', aliases: ['sherlock_bot', 'SherlockOSINTBot'] },
  { name: 'Maigret Bot', username: 'maigretbot', aliases: ['maigret_bot', 'MaigretOSINTBot'] },
  
  // Leak check bots
  { name: 'LeakCheck Bot', username: 'leakcheckbot', aliases: ['leak_check_bot', 'LeakCheckOSINTBot'] },
  { name: 'Have I Been Pwned Bot', username: 'hibpbot', aliases: ['haveibeenpwned_bot'] },
  
  // Other OSINT bots
  { name: 'FindClone Bot', username: 'findclonebot', aliases: ['find_clone_bot', 'FindCloneOSINTBot'] },
  { name: 'SearchFace Bot', username: 'searchfacebot', aliases: ['search_face_bot'] },
  { name: 'Telegram Analytics', username: 'tganalytics_bot', aliases: ['tganalyticsbot'] },
]

// ============================================
// REAL-TIME OSINT DETECTION
// ============================================

interface OSINTAlert {
  userId: number
  attackerInfo: {
    userId?: number
    username?: string
    firstName?: string
  }
  service: string
  queryType: 'phone' | 'username' | 'email'
  queryData: string
  timestamp: Date
  riskLevel: 'low' | 'medium' | 'high' | 'critical'
}

// Log and detect OSINT query attempt
// IMPORTANT: Only sends notifications if protection_enabled is TRUE
export async function detectOSINTQuery(
  targetQuery: string,
  queryType: 'phone' | 'username' | 'email',
  attackerUserId?: number,
  attackerUsername?: string,
  sourceBot?: string
): Promise<OSINTAlert | null> {
  // Find protected user by their monitored data
  const column = queryType === 'phone' ? 'monitored_phones' : 
                 queryType === 'email' ? 'monitored_emails' : 'monitored_usernames'
  
  // Normalize query for matching
  const normalizedQuery = targetQuery.toLowerCase().replace('@', '').replace(/[^\w\d+@.]/g, '')
  
  const { data: users } = await supabase
    .from('tg_users')
    .select('id, first_name, notifications_enabled, protection_enabled')
    .contains(column, [normalizedQuery])

  if (!users || users.length === 0) {
    return null
  }

  const user = users[0]
  
  // CRITICAL: Only process if protection is ENABLED
  // If protection is off, we do NOT notify and do NOT save threat
  if (!user.protection_enabled) {
    return null
  }
  
  // Create alert
  const alert: OSINTAlert = {
    userId: user.id,
    attackerInfo: {
      userId: attackerUserId,
      username: attackerUsername,
    },
    service: sourceBot || 'Unknown OSINT Service',
    queryType,
    queryData: targetQuery,
    timestamp: new Date(),
    riskLevel: sourceBot?.includes('Глаз') || sourceBot?.includes('Quick') ? 'critical' : 'high',
  }

  // Save threat to database (only when protection is enabled)
  await supabase.from('threats').insert({
    user_id: user.id,
    threat_type: 'osint_scan',
    source: alert.service,
    query_data: targetQuery,
    attacker_id: attackerUserId,
    attacker_username: attackerUsername,
    risk_level: alert.riskLevel,
    blocked: true,
  })

  // Update user stats
  const { data: userData } = await supabase
    .from('tg_users')
    .select('protection_stats')
    .eq('id', user.id)
    .single()

  if (userData) {
    const stats = userData.protection_stats || { threats_blocked: 0, scans_detected: 0 }
    await supabase.from('tg_users').update({
      protection_stats: {
        ...stats,
        threats_blocked: (stats.threats_blocked || 0) + 1,
        scans_detected: (stats.scans_detected || 0) + 1,
        last_threat: new Date().toISOString(),
      },
    }).eq('id', user.id)
  }

  // Send notification if notifications are enabled (protection check already passed above)
  if (user.notifications_enabled) {
    await sendOSINTAlertNotification(alert)
  }

  return alert
}

// Send OSINT alert notification to user
async function sendOSINTAlertNotification(alert: OSINTAlert) {
  const riskEmoji = {
    low: '🟡',
    medium: '🟠',
    high: '🔴',
    critical: '⛔️',
  }[alert.riskLevel]

  const attackerInfo = alert.attackerInfo.username
    ? `@${alert.attackerInfo.username}`
    : alert.attackerInfo.userId
    ? `ID: ${alert.attackerInfo.userId}`
    : 'Неизвестный пользователь'

  const message = `
${riskEmoji} <b>ВНИМАНИЕ! ОБНАРУЖЕН ПРОБИВ!</b>

━━━━━━━━━━━━━━━━━━━━

<b>Кто пытается пробить:</b>
👤 ${attackerInfo}

<b>Что ищут:</b>
📎 <code>${alert.queryData}</code>

<b>Где ищут:</b>
🤖 ${alert.service}

<b>Время:</b>
🕐 ${alert.timestamp.toLocaleString('ru-RU', { timeZone: 'Europe/Moscow' })}

━━━━━━━━━━━━━━━━━━━━

🛡 <b>Статус:</b> Активность зафиксирована
<i>vacwerTOR защищает ваши данные</i>
`

  const keyboard = {
    inline_keyboard: [
      [{ text: '📊 Подробнее', callback_data: 'threat_history' }],
      [{ text: '🛡 Усилить защиту', callback_data: 'settings' }],
      [{ text: '◀️ Меню', callback_data: 'menu' }],
    ],
  }

  await sendTelegramMessage(alert.userId, message, keyboard)
}

// ============================================
// CANARY TOKEN SYSTEM
// ============================================

// Create unique canary URLs that trigger alerts when accessed
export async function createCanaryToken(userId: number, dataType: string): Promise<string> {
  const token = generateHoneypotToken(userId, dataType)
  const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'https://vacwertor.vercel.app'
  
  // Save canary token to database
  await supabase.from('canary_tokens').insert({
    user_id: userId,
    token,
    data_type: dataType,
    created_at: new Date().toISOString(),
  })

  return `${baseUrl}/api/canary/${token}`
}

// Handle canary token access - this triggers when someone visits the canary URL
// IMPORTANT: Only alerts if protection_enabled is TRUE
export async function handleCanaryAccess(
  token: string,
  ipAddress?: string,
  userAgent?: string,
  referer?: string
): Promise<boolean> {
  const parsed = parseHoneypotToken(token)
  if (!parsed) return false

  // Get user with protection status
  const { data: user } = await supabase
    .from('tg_users')
    .select('id, first_name, notifications_enabled, protection_enabled')
    .eq('id', parsed.userId)
    .single()

  if (!user) return false
  
  // CRITICAL: Only process if protection is ENABLED
  if (!user.protection_enabled) {
    return false
  }

  // Log access (only when protection is enabled)
  await supabase.from('canary_accesses').insert({
    token,
    user_id: user.id,
    ip_address: ipAddress,
    user_agent: userAgent,
    referer,
    accessed_at: new Date().toISOString(),
  })

  // Save as threat
  await supabase.from('threats').insert({
    user_id: user.id,
    threat_type: 'canary_triggered',
    source: referer || 'Direct Access',
    ip_address: ipAddress,
    query_data: token,
    risk_level: 'critical',
    blocked: true,
  })

  // Send alert if notifications enabled (protection check already passed)
  if (user.notifications_enabled) {
    const message = `
⛔️ <b>КРИТИЧЕСКОЕ ОПОВЕЩЕНИЕ!</b>

━━━━━━━━━━━━━━━━━━━━

<b>Ваши данные были найдены!</b>

Кто-то получил доступ к вашему 
канареечному токену:

📍 <b>IP:</b> <code>${ipAddress || 'Скрыт'}</code>
🌐 <b>Источник:</b> ${referer || 'Прямой доступ'}
📱 <b>Тип данных:</b> ${parsed.dataType}
🕐 <b>Время:</b> ${new Date().toLocaleString('ru-RU')}

━━━━━━━━━━━━━━━━━━━━

<b>Это означает, что кто-то активно 
ищет информацию о вас!</b>

🛡 Рекомендуем усилить защиту
`

    await sendTelegramMessage(user.id, message)
  }

  return true
}

// ============================================
// PERIODIC BREACH CHECK
// ============================================

export async function checkUserBreaches(userId: number): Promise<{
  hasBreaches: boolean
  newBreaches: string[]
}> {
  const { data: user } = await supabase
    .from('tg_users')
    .select('monitored_emails, known_breaches')
    .eq('id', userId)
    .single()

  if (!user || !user.monitored_emails?.length) {
    return { hasBreaches: false, newBreaches: [] }
  }

  const knownBreaches = user.known_breaches || []
  const newBreaches: string[] = []

  for (const email of user.monitored_emails) {
    const result = await checkHIBP(email)
    if (result.breached) {
      for (const breach of result.breaches) {
        if (!knownBreaches.includes(breach)) {
          newBreaches.push(`${email}: ${breach}`)
        }
      }
    }
  }

  if (newBreaches.length > 0) {
    // Update known breaches
    await supabase.from('tg_users').update({
      known_breaches: [...knownBreaches, ...newBreaches],
    }).eq('id', userId)

    // Save threat
    await supabase.from('threats').insert({
      user_id: userId,
      threat_type: 'data_breach',
      source: 'HaveIBeenPwned',
      query_data: newBreaches.join(', '),
      risk_level: 'critical',
      blocked: false,
    })
  }

  return { hasBreaches: newBreaches.length > 0, newBreaches }
}

// ============================================
// GETCONTACT API INTEGRATION
// ============================================

export async function checkGetContact(phone: string): Promise<{
  found: boolean
  names: string[]
  tags: string[]
}> {
  // GetContact requires their official API or app
  // This is a placeholder for when API access is available
  const apiKey = process.env.GETCONTACT_API_KEY
  if (!apiKey) return { found: false, names: [], tags: [] }

  try {
    // GetContact API endpoint (requires partnership)
    const response = await fetch(`https://api.getcontact.com/v1/search`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ phone }),
    })

    if (response.ok) {
      const data = await response.json()
      return {
        found: data.found || false,
        names: data.names || [],
        tags: data.tags || [],
      }
    }
  } catch {
    // API not available
  }

  return { found: false, names: [], tags: [] }
}

// ============================================
// EXPORT MONITORING FUNCTIONS
// ============================================

export {
  OSINT_TELEGRAM_BOTS,
  sendTelegramMessage,
}
