export async function register() {
  // This runs once when the server starts
  if (process.env.NEXT_RUNTIME === "nodejs") {
    const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN
    const VERCEL_URL = process.env.VERCEL_URL
    const VERCEL_PROJECT_PRODUCTION_URL = process.env.VERCEL_PROJECT_PRODUCTION_URL

    if (!BOT_TOKEN) {
      console.log("[vacwerTOR] No TELEGRAM_BOT_TOKEN found, skipping webhook setup")
      return
    }

    // Determine the base URL
    let baseUrl = ""
    if (VERCEL_PROJECT_PRODUCTION_URL) {
      baseUrl = `https://${VERCEL_PROJECT_PRODUCTION_URL}`
    } else if (VERCEL_URL) {
      baseUrl = `https://${VERCEL_URL}`
    } else {
      console.log("[vacwerTOR] No Vercel URL found, skipping webhook setup")
      return
    }

    const webhookUrl = `${baseUrl}/api/telegram/webhook`

    console.log("[vacwerTOR] Setting up Telegram webhook...")
    console.log("[vacwerTOR] Webhook URL:", webhookUrl)

    try {
      // Delete old webhook
      await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/deleteWebhook`)

      // Set new webhook
      const response = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/setWebhook`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: webhookUrl,
          allowed_updates: ["message", "callback_query"],
          drop_pending_updates: true,
        }),
      })

      const result = await response.json()

      if (result.ok) {
        console.log("[vacwerTOR] Webhook successfully registered!")
      } else {
        console.error("[vacwerTOR] Failed to register webhook:", result)
      }

      // Set bot commands - only /start, everything else via inline buttons
      await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/setMyCommands`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          commands: [
            { command: "start", description: "Запустить бота" },
          ],
        }),
      })

      console.log("[vacwerTOR] Bot commands set successfully!")
    } catch (error) {
      console.error("[vacwerTOR] Error setting up webhook:", error)
    }
  }
}
