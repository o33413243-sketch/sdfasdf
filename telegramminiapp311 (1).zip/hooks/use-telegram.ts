"use client"

import { useEffect, useState, useCallback } from "react"
import type { TelegramUser, TelegramWebApp } from "@/types/telegram"

export function useTelegram() {
  const [webApp, setWebApp] = useState<TelegramWebApp | null>(null)
  const [user, setUser] = useState<TelegramUser | null>(null)
  const [isReady, setIsReady] = useState(false)

  useEffect(() => {
    const script = document.createElement("script")
    script.src = "https://telegram.org/js/telegram-web-app.js"
    script.async = true
    script.onload = () => {
      const tg = window.Telegram?.WebApp
      if (tg) {
        tg.ready()
        tg.expand()
        setWebApp(tg)
        setUser(tg.initDataUnsafe?.user || null)
        setIsReady(true)
      }
    }
    document.head.appendChild(script)

    return () => {
      document.head.removeChild(script)
    }
  }, [])

  const hapticFeedback = useCallback(
    (type: "light" | "medium" | "heavy" = "medium") => {
      webApp?.HapticFeedback?.impactOccurred(type)
    },
    [webApp],
  )

  const showAlert = useCallback(
    (message: string) => {
      if (webApp) {
        // Use native alert as Telegram WebApp might not support all methods
        alert(message)
      }
    },
    [webApp],
  )

  return {
    webApp,
    user,
    isReady,
    hapticFeedback,
    showAlert,
  }
}
