-- vacwerTOR Full Database Setup
-- Run this script once after connecting Supabase

-- 1. Create main users table
CREATE TABLE IF NOT EXISTS tg_users (
  id BIGINT PRIMARY KEY,
  username TEXT,
  first_name TEXT,
  last_name TEXT,
  photo_url TEXT,
  is_premium BOOLEAN DEFAULT FALSE,
  protection_enabled BOOLEAN DEFAULT FALSE,
  notifications_enabled BOOLEAN DEFAULT TRUE,
  monitored_usernames TEXT[] DEFAULT '{}',
  monitored_phones TEXT[] DEFAULT '{}',
  monitored_emails TEXT[] DEFAULT '{}',
  known_breaches TEXT[] DEFAULT '{}',
  protection_stats JSONB DEFAULT '{"threats_blocked": 0, "scans_detected": 0, "last_threat": null}'::jsonb,
  last_scan_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Create threats table
CREATE TABLE IF NOT EXISTS threats (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id BIGINT REFERENCES tg_users(id) ON DELETE CASCADE,
  threat_type TEXT NOT NULL,
  source TEXT NOT NULL,
  source_url TEXT,
  ip_address TEXT,
  region TEXT,
  query_data TEXT,
  attacker_id BIGINT,
  attacker_username TEXT,
  risk_level TEXT DEFAULT 'medium',
  blocked BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Create canary tokens table
CREATE TABLE IF NOT EXISTS canary_tokens (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES tg_users(id) ON DELETE CASCADE,
  token TEXT NOT NULL UNIQUE,
  data_type TEXT NOT NULL,
  description TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  access_count INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  last_accessed_at TIMESTAMP WITH TIME ZONE
);

-- 4. Create canary access logs
CREATE TABLE IF NOT EXISTS canary_accesses (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  token TEXT NOT NULL,
  user_id BIGINT NOT NULL REFERENCES tg_users(id) ON DELETE CASCADE,
  ip_address TEXT,
  user_agent TEXT,
  referer TEXT,
  country TEXT,
  city TEXT,
  accessed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. Create indexes
CREATE INDEX IF NOT EXISTS idx_tg_users_username ON tg_users(username);
CREATE INDEX IF NOT EXISTS idx_tg_users_protection_enabled ON tg_users(protection_enabled);
CREATE INDEX IF NOT EXISTS idx_tg_users_monitored_usernames ON tg_users USING GIN (monitored_usernames);
CREATE INDEX IF NOT EXISTS idx_tg_users_monitored_phones ON tg_users USING GIN (monitored_phones);
CREATE INDEX IF NOT EXISTS idx_tg_users_monitored_emails ON tg_users USING GIN (monitored_emails);
CREATE INDEX IF NOT EXISTS idx_threats_user_id ON threats(user_id);
CREATE INDEX IF NOT EXISTS idx_threats_created_at ON threats(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_threats_attacker ON threats(attacker_id);
CREATE INDEX IF NOT EXISTS idx_canary_tokens_user ON canary_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_canary_tokens_token ON canary_tokens(token);
CREATE INDEX IF NOT EXISTS idx_canary_accesses_token ON canary_accesses(token);
CREATE INDEX IF NOT EXISTS idx_canary_accesses_user ON canary_accesses(user_id);

-- 6. Enable RLS
ALTER TABLE tg_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE threats ENABLE ROW LEVEL SECURITY;
ALTER TABLE canary_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE canary_accesses ENABLE ROW LEVEL SECURITY;

-- 7. Create RLS policies (permissive for API access)
DROP POLICY IF EXISTS "Allow all for tg_users" ON tg_users;
CREATE POLICY "Allow all for tg_users" ON tg_users FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Allow all for threats" ON threats;
CREATE POLICY "Allow all for threats" ON threats FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Allow all for canary_tokens" ON canary_tokens;
CREATE POLICY "Allow all for canary_tokens" ON canary_tokens FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Allow all for canary_accesses" ON canary_accesses;
CREATE POLICY "Allow all for canary_accesses" ON canary_accesses FOR ALL USING (true) WITH CHECK (true);

-- 8. Helper functions
CREATE OR REPLACE FUNCTION normalize_phone(phone TEXT) RETURNS TEXT AS $$
BEGIN
  RETURN regexp_replace(phone, '[^0-9+]', '', 'g');
END;
$$ LANGUAGE plpgsql IMMUTABLE;

CREATE OR REPLACE FUNCTION is_user_protected(check_user_id BIGINT) RETURNS BOOLEAN AS $$
DECLARE
  protected BOOLEAN;
BEGIN
  SELECT protection_enabled INTO protected FROM tg_users WHERE id = check_user_id;
  RETURN COALESCE(protected, false);
END;
$$ LANGUAGE plpgsql STABLE;

-- 9. Canary access trigger
CREATE OR REPLACE FUNCTION increment_canary_access()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE canary_tokens 
  SET access_count = access_count + 1,
      last_accessed_at = NOW()
  WHERE token = NEW.token;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_canary_access ON canary_accesses;
CREATE TRIGGER trigger_canary_access
  AFTER INSERT ON canary_accesses
  FOR EACH ROW
  EXECUTE FUNCTION increment_canary_access();
