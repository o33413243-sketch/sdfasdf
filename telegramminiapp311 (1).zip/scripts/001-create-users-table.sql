-- Create users table for Telegram Mini App
CREATE TABLE IF NOT EXISTS tg_users (
  id BIGINT PRIMARY KEY,
  username TEXT,
  first_name TEXT,
  last_name TEXT,
  photo_url TEXT,
  is_premium BOOLEAN DEFAULT FALSE,
  protection_enabled BOOLEAN DEFAULT FALSE,
  protection_stats JSONB DEFAULT '{"blocked": 0, "alerts": 0, "scans": 0}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE tg_users ENABLE ROW LEVEL SECURITY;

-- Create policy for users to read/write their own data
CREATE POLICY "Users can read own data" ON tg_users FOR SELECT USING (true);
CREATE POLICY "Users can insert own data" ON tg_users FOR INSERT WITH CHECK (true);
CREATE POLICY "Users can update own data" ON tg_users FOR UPDATE USING (true);

-- Create index for faster lookups
CREATE INDEX idx_tg_users_username ON tg_users(username);
