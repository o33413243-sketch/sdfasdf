-- Update protection system tables
-- Ensures all necessary columns exist for real OSINT detection

-- Add protection_enabled column if not exists
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tg_users' AND column_name = 'protection_enabled'
  ) THEN
    ALTER TABLE tg_users ADD COLUMN protection_enabled BOOLEAN DEFAULT false;
  END IF;
END $$;

-- Add notifications_enabled column if not exists
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tg_users' AND column_name = 'notifications_enabled'
  ) THEN
    ALTER TABLE tg_users ADD COLUMN notifications_enabled BOOLEAN DEFAULT true;
  END IF;
END $$;

-- Ensure monitored data columns exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tg_users' AND column_name = 'monitored_usernames'
  ) THEN
    ALTER TABLE tg_users ADD COLUMN monitored_usernames TEXT[] DEFAULT '{}';
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tg_users' AND column_name = 'monitored_phones'
  ) THEN
    ALTER TABLE tg_users ADD COLUMN monitored_phones TEXT[] DEFAULT '{}';
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tg_users' AND column_name = 'monitored_emails'
  ) THEN
    ALTER TABLE tg_users ADD COLUMN monitored_emails TEXT[] DEFAULT '{}';
  END IF;
END $$;

-- Update protection_stats to JSONB if needed
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tg_users' AND column_name = 'protection_stats'
  ) THEN
    -- Ensure default value is set
    ALTER TABLE tg_users ALTER COLUMN protection_stats SET DEFAULT '{"threats_blocked": 0, "scans_detected": 0, "last_threat": null}'::jsonb;
  END IF;
END $$;

-- Create indexes for faster OSINT detection queries
CREATE INDEX IF NOT EXISTS idx_tg_users_monitored_usernames ON tg_users USING GIN (monitored_usernames);
CREATE INDEX IF NOT EXISTS idx_tg_users_monitored_phones ON tg_users USING GIN (monitored_phones);
CREATE INDEX IF NOT EXISTS idx_tg_users_monitored_emails ON tg_users USING GIN (monitored_emails);
CREATE INDEX IF NOT EXISTS idx_tg_users_protection_enabled ON tg_users (protection_enabled);

-- Create function to normalize phone numbers for matching
CREATE OR REPLACE FUNCTION normalize_phone(phone TEXT) RETURNS TEXT AS $$
BEGIN
  RETURN regexp_replace(phone, '[^0-9+]', '', 'g');
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Create function to check if user is protected
CREATE OR REPLACE FUNCTION is_user_protected(user_id BIGINT) RETURNS BOOLEAN AS $$
DECLARE
  protected BOOLEAN;
BEGIN
  SELECT protection_enabled INTO protected FROM tg_users WHERE id = user_id;
  RETURN COALESCE(protected, false);
END;
$$ LANGUAGE plpgsql STABLE;
