-- Add monitoring data columns to tg_users
ALTER TABLE tg_users 
ADD COLUMN IF NOT EXISTS monitored_usernames TEXT[] DEFAULT '{}',
ADD COLUMN IF NOT EXISTS monitored_phones TEXT[] DEFAULT '{}',
ADD COLUMN IF NOT EXISTS monitored_emails TEXT[] DEFAULT '{}',
ADD COLUMN IF NOT EXISTS notifications_enabled BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS last_scan_at TIMESTAMP WITH TIME ZONE;

-- Create threats table for storing detected threats
CREATE TABLE IF NOT EXISTS threats (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id BIGINT REFERENCES tg_users(id) ON DELETE CASCADE,
  threat_type TEXT NOT NULL,
  source TEXT NOT NULL,
  source_url TEXT,
  ip_address TEXT,
  region TEXT,
  query_data TEXT,
  blocked BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_threats_user_id ON threats(user_id);
CREATE INDEX IF NOT EXISTS idx_threats_created_at ON threats(created_at DESC);

-- Enable RLS on threats table
ALTER TABLE threats ENABLE ROW LEVEL SECURITY;

-- RLS policies for threats
CREATE POLICY "Users can read own threats" ON threats
  FOR SELECT USING (user_id = current_setting('app.current_user_id')::bigint);

CREATE POLICY "System can insert threats" ON threats
  FOR INSERT WITH CHECK (true);
