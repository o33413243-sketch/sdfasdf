-- Canary Tokens for OSINT Detection
-- These are honeypot URLs that trigger alerts when accessed

-- Canary tokens table
CREATE TABLE IF NOT EXISTS canary_tokens (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES tg_users(id) ON DELETE CASCADE,
  token TEXT NOT NULL UNIQUE,
  data_type TEXT NOT NULL, -- 'phone', 'email', 'username', 'document'
  description TEXT,
  is_active BOOLEAN DEFAULT true,
  access_count INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  last_accessed_at TIMESTAMP WITH TIME ZONE
);

-- Canary access logs
CREATE TABLE IF NOT EXISTS canary_accesses (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  token TEXT NOT NULL,
  user_id BIGINT NOT NULL REFERENCES tg_users(id) ON DELETE CASCADE,
  ip_address TEXT,
  user_agent TEXT,
  referer TEXT,
  country TEXT,
  city TEXT,
  accessed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add known_breaches column to tg_users if not exists
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tg_users' AND column_name = 'known_breaches'
  ) THEN
    ALTER TABLE tg_users ADD COLUMN known_breaches TEXT[] DEFAULT '{}';
  END IF;
END $$;

-- Add attacker info columns to threats table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'threats' AND column_name = 'attacker_id'
  ) THEN
    ALTER TABLE threats ADD COLUMN attacker_id BIGINT;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'threats' AND column_name = 'attacker_username'
  ) THEN
    ALTER TABLE threats ADD COLUMN attacker_username TEXT;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'threats' AND column_name = 'risk_level'
  ) THEN
    ALTER TABLE threats ADD COLUMN risk_level TEXT DEFAULT 'medium';
  END IF;
END $$;

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_canary_tokens_user ON canary_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_canary_tokens_token ON canary_tokens(token);
CREATE INDEX IF NOT EXISTS idx_canary_accesses_token ON canary_accesses(token);
CREATE INDEX IF NOT EXISTS idx_canary_accesses_user ON canary_accesses(user_id);
CREATE INDEX IF NOT EXISTS idx_threats_attacker ON threats(attacker_id);

-- Update function to increment access count
CREATE OR REPLACE FUNCTION increment_canary_access()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE canary_tokens 
  SET access_count = access_count + 1,
      last_accessed_at = NOW()
  WHERE token = NEW.token;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for canary access
DROP TRIGGER IF EXISTS trigger_canary_access ON canary_accesses;
CREATE TRIGGER trigger_canary_access
  AFTER INSERT ON canary_accesses
  FOR EACH ROW
  EXECUTE FUNCTION increment_canary_access();
